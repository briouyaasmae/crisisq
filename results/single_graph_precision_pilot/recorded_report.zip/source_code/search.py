"""Label-free, bounded calibration objective; never imported by evaluation workers."""
import numpy as np
from common import decision

def assess(probabilities,references,gate,tau,size_mb):
 versions=sorted(references);loss=[];extra=[];total=[];mse=[];hybrid=[]
 for version in versions:
  p=np.asarray(probabilities[version]);f=np.asarray(references[version]);q=decision(p,gate,tau);r=decision(f,gate,tau)
  # These are FP32-reference decisions, NOT source-positive/negative labels.
  loss.append(int(((r==1)&(q==0)).sum()));extra.append(int(((r==0)&(q==1)).sum()));total.append(int((r!=q).sum()));mse.append(float(np.mean((p-f)**2)));hybrid.append(q)
 cross=int((hybrid[0]!=hybrid[1]).sum()) if len(hybrid)==2 else 0
 return dict(worst_reference_positive_losses=max(loss),worst_added_reference_negative_alerts=max(extra),worst_total_disagreements=max(total),cross_runtime_disagreements=cross,worst_score_mse=max(mse),size_mb=float(size_mb),per_runtime={v:dict(reference_positive_losses=loss[i],added_reference_negative_alerts=extra[i],total_disagreements=total[i],score_mse=mse[i]) for i,v in enumerate(versions)})
def rank(record):return (record['worst_reference_positive_losses'],record['worst_total_disagreements'],record['cross_runtime_disagreements'],record['worst_score_mse'])
def feasible(record,limit):return record['size_mb']<=limit and record['worst_total_disagreements']==0

def choose(records,current,limit):
 valid=[r for r in records if feasible(r,limit)]
 if valid:return min(valid,key=lambda r:(r['size_mb'],rank(r),r['id'])),True
 improving=[r for r in records if r['size_mb']<=limit and rank(r)<rank(current)]
 return (min(improving,key=lambda r:(rank(r),r['size_mb'],r['id'])) if improving else None),False
