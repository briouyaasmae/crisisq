import os
os.environ['MPLBACKEND']='Agg'
from pathlib import Path
import csv,json,sys
import numpy as np
from common import atomic

def main(root):
 root=Path(root);rows=list(csv.DictReader((root/'metrics.csv').open()));timing=list(csv.DictReader((root/'timing_summary.csv').open()));runtime=list(csv.DictReader((root/'runtime_disagreements.csv').open()));selection=json.loads((root/'selection_frozen.json').read_text());findings=['One calibration-selected graph; weights/rules/classification thresholds frozen. New quantization allocation, not a newly trained classifier.','Restored groups: '+', '.join(selection['groups'])+'.','Calibration reference agreement does not guarantee source-label accuracy, portable kernels or phone benefit.'];comparisons=[]
 for version in ['1.31.1','1.28.0']:
  for part in ['binary_test','positive_probe','labeled_hard_negative','sdcnl_authors_test']:
   chosen=next(r for r in rows if r['model']=='saqs__42' and r['runtime']==version and r['mode']=='hybrid' and r['partition']==part and r['variant']=='selected_single_graph');q=next(r for r in rows if r['model']=='saqs__42' and r['runtime']==version and r['mode']=='hybrid' and r['partition']==part and r['variant']=='original_quantized');findings.append(f"{version} {part}: source-positive losses vs FP32 {q['positive_losses_vs_fp32']} -> {chosen['positive_losses_vs_fp32']}; gained vs Q={chosen['positive_gains_vs_quantized']}, lost vs Q={chosen['positive_losses_vs_quantized']}; added/removed source-negative alerts={chosen['added_source_negative_alerts_vs_quantized']}/{chosen['removed_source_negative_alerts_vs_quantized']}; recall={chosen['source_positive_recall']}; source-negative alert rate={chosen['source_negative_alert_rate']}.");comparisons.append(dict(runtime=version,partition=part,original_losses=int(q['positive_losses_vs_fp32']),selected_losses=int(chosen['positive_losses_vs_fp32'])))
  t=next(r for r in timing if r['runtime']==version and r['variant']=='selected_single_graph');q=next(r for r in timing if r['runtime']==version and r['variant']=='original_quantized');findings.append(f"{version} host single-graph pipeline: candidate speedup vs FP32={float(t['speedup_vs_fp32']):.3f}; original Q speedup={float(q['speedup_vs_fp32']):.3f}; PSS MiB candidate/Q={t['mean_pss_mib']}/{q['mean_pss_mib']}; live-vs-saved timing disagreements={t['live_vs_saved_disagreements']}.")
 for part in ['binary_test','sdcnl_authors_test']:
  q=next(r for r in runtime if r['model']=='saqs__42' and r['variant']=='original_quantized' and r['partition']==part);s=next(r for r in runtime if r['model']=='saqs__42' and r['variant']=='selected_single_graph' and r['partition']==part);findings.append(f"{part} cross-runtime hybrid decision disagreements Q -> candidate: {q['hybrid_cross_runtime_disagreements']} -> {s['hybrid_cross_runtime_disagreements']}.")
 findings+=['Check BOTH heuristic controls and regenerated-Q baseline in metrics.csv, and CE42/SAQS123 transfer when present. A gain over only original Q may reflect graph regeneration. Do not suppress worse recall, extra alerts, slower timings or failed checkpoint transfer.','Evaluation sources were inspected previously. This is follow-up engineering evidence, not independent clinical validation.','No substantially new general mixed-precision algorithm is established: per-node selective quantization has prior art (SeQTO). Phone latency/RAM/thermal behavior remain unmeasured for this candidate.'];(root/'KEY_FINDINGS.txt').write_text('\n'.join(findings)+'\n');atomic(root/'primary_comparisons.json',comparisons)
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout='constrained');x=np.arange(3)
 for ax,version in zip(axes,['1.31.1','1.28.0']):
  rr=[r for r in comparisons if r['runtime']==version and r['partition']!='labeled_hard_negative'];a=ax.bar(x-.18,[r['original_losses'] for r in rr],.36,label='Original QUInt8');b=ax.bar(x+.18,[r['selected_losses'] for r in rr],.36,label='Selected single graph');ax.bar_label(a,padding=3);ax.bar_label(b,padding=3);ax.set_xticks(x,['Twitter main','Twitter probe','SDCNL']);ax.tick_params(axis='x',labelsize=8);ax.set_title('ORT '+version);ax.set_ylabel('Source-positive losses versus FP32');ax.set_ylim(0,max(1,max(r['original_losses'] for r in rr),max(r['selected_losses'] for r in rr))*1.25+1);ax.legend(fontsize=8)
 fig.suptitle('Previously inspected evaluation sources; calibration rows excluded');fig.savefig(root/'primary_positive_losses.png',dpi=180);fig.savefig(root/'primary_positive_losses.svg');plt.close(fig)
if __name__=='__main__':main(sys.argv[1])
