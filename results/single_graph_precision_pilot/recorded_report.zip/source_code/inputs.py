from pathlib import Path
import base64,collections,csv,gzip,hashlib,io,json,urllib.request
import numpy as np
from common import sha,digest,atomic,freeze,gates
HERE=Path(__file__).resolve().parent

def twitter(config):
 import build_full_device_packet
 seed=json.loads(gzip.decompress((HERE/'full_evaluation_seed.json.gz').read_bytes()));temp=Path(config['temporary_root']);temp.mkdir(parents=True,exist_ok=True)
 expected='a24de8c2b432ddbe3880a579abc9106cde59d38b9f545eeae30f73ad955b1372';packet=temp/'packet/full_evaluation_cases.jsonl'
 if not packet.exists():
  match=next((p for p in sorted(Path(config['input_root']).rglob('full_evaluation_cases.jsonl')) if sha(p)==expected),None)
  if match is not None:packet=match
  else:build_full_device_packet.main(seed,temp/'packet')
 assert sha(packet)==expected
 rows=[json.loads(v) for v in packet.read_text().splitlines()];assert len(rows)==1700
 gate=gates(json.loads((HERE/'frozen_rules.json').read_text()))
 for r in rows:
  g,_=gate(r['text']);assert (-1 if g is None else g)==r['gate_v2'],'Frozen gate differs'
 assert digest(json.loads((HERE/'external_frozen.json').read_text()))==seed['external_plan_hash']
 data=base64.b64decode(seed['tokenizer_base64']);assert hashlib.sha256(data).hexdigest()==seed['model_hashes']['tokenizer.json'];(temp/'tokenizer.json').write_bytes(data)
 return rows

def discover(config):
 external=json.loads((HERE/'external_frozen.json').read_text());selection=json.loads((HERE/'selection_frozen.json').read_text());assert digest(selection)==external['source_selection_hash'];requested=[('saqs',42),('saqs',123),('ce',42)] if config['model_scope']=='fixed_extensions' else [('saqs',42)];wanted={}
 for arm,seed in requested:
  sel=selection['models'][f'{arm}__{seed}']['selected'];assert sel and sel['variant']=='q_quint8'
  for kind in ['fp32','q_quint8']:
   job=external['jobs'][f'{arm}__{seed}__{kind}'];values=[v for k,v in job['files'].items() if k.endswith('.onnx')];assert len(values)==1;wanted[(arm,seed,kind)]=values[0]
 found={}
 for p in sorted(Path(config['input_root']).rglob('*.onnx')):
  value=sha(p)
  if value in set(wanted.values()):found.setdefault(value,str(p))
  if len(found)==len(set(wanted.values())):break
 pairs=[];coverage=[]
 for arm,seed in requested:
  present=all(wanted[arm,seed,k] in found for k in ['fp32','q_quint8']);coverage.append(dict(arm=arm,seed=seed,included=present))
  if not present:
   if (arm,seed)==('saqs',42):raise FileNotFoundError('Attach the same WHOLE original model-containing nonclinical notebook output. Exact primary FP32/QUInt8 weights are missing; no input ZIP is needed.')
   continue
  pair=dict(id=f'{arm}__{seed}',tau=selection['models'][f'{arm}__{seed}']['selected']['tau'])
  for label,k in [('fp32','fp32'),('original_quantized','q_quint8')]:pair[label]=dict(path=found[wanted[arm,seed,k]],sha256=wanted[arm,seed,k])
  pairs.append(pair)
 return pairs,coverage

def calibration(config):
 rows=twitter(config);sizes={('binary_test',1):64,('binary_test',0):64,('positive_probe',1):64,('positive_probe',0):32,('labeled_hard_negative',0):32};indices=[]
 for (part,label),n in sizes.items():
  pool=[i for i,r in enumerate(rows) if r['partition']==part and r['label']==label];pool.sort(key=lambda i:hashlib.sha256(('CrisisQ-runtime-panel-v1|'+rows[i]['source_id']).encode()).hexdigest());indices+=pool[:n]
 indices=sorted(indices);assert len(set(indices))==256
 # The old panel was label-stratified. New precision selection receives no source labels.
 meta=[{k:rows[i][k] for k in ['source_id','text_hash','gate_v2','group_id','partition']} for i in indices];temp=Path(config['temporary_root']);path=temp/'calibration_inputs.npz'
 ids=np.array([rows[i]['input_ids'] for i in indices],np.int64);mask=np.array([rows[i]['attention_mask'] for i in indices],np.int64)
 if path.exists():
  with np.load(path,allow_pickle=False) as old:assert np.array_equal(old['input_ids'],ids) and np.array_equal(old['attention_mask'],mask)
 else:np.savez_compressed(path,input_ids=ids,attention_mask=mask)
 freeze(Path(config['output_root'])/'calibration_metadata.json',meta)
 return meta,path

def evaluation(config):
 root=Path(config['output_root']);assert (root/'selection_frozen.json').is_file(),'Evaluation is locked until calibration selection is frozen'
 selected=json.loads((root/'selection_frozen.json').read_text());assert selected['accepted']
 from tokenizers import Tokenizer
 from build_full_device_packet import normal
 temp=Path(config['temporary_root']);original=twitter(config);cal={r['source_id'] for r in json.loads((root/'calibration_metadata.json').read_text())};known={r['text_hash'] for r in original};meta=[];ids=[];masks=[];texts=[]
 for r in original:
  if r['source_id'] in cal:continue
  meta.append({k:r[k] for k in ['source_id','text_hash','label','group_id','partition','gate_v2']});ids.append(r['input_ids']);masks.append(r['attention_mask']);texts.append(r['text'])
 assert len(meta)==1444
 record=json.loads((HERE/'source_manifest.json').read_text())['files']['testing-set.csv'];source=temp/'testing-set.csv'
 if not source.exists():
  data=urllib.request.urlopen(urllib.request.Request(record['url'],headers={'User-Agent':'CrisisQ-single-graph-pilot'}),timeout=120).read();assert hashlib.sha256(data).hexdigest()==record['sha256'];source.write_bytes(data)
 assert sha(source)==record['sha256'];test=list(csv.DictReader(io.StringIO(source.read_text(encoding='utf-8-sig'))));assert len(test)==379
 gate=gates(json.loads((HERE/'frozen_rules.json').read_text()));tok=Tokenizer.from_file(str(temp/'tokenizer.json'));tok.enable_truncation(max_length=128);tok.enable_padding(length=128,pad_id=0,pad_token='[PAD]');staged=[];labels=collections.defaultdict(set)
 for i,r in enumerate(test):
  text=r['title'].strip()+'\n\n'+r['selftext'].strip();h=hashlib.sha256(normal(text).encode()).hexdigest();bh=hashlib.sha256(normal(r['selftext']).encode()).hexdigest();label=int(r['is_suicide']);assert label in [0,1];staged.append((i,r,text,h,bh,label));labels[h].add(label)
 seen=set();excluded=[]
 for i,r,text,h,bh,label in staged:
  reason='known_twitter_overlap' if h in known or bh in known else 'removed_empty' if normal(r['selftext']) in ['','removed','deleted'] else 'conflicting_label' if len(labels[h])>1 else 'duplicate' if h in seen else None;seen.add(h)
  if reason:excluded.append(dict(source_id='sdcnl:test:'+str(i),text_hash=h,reason=reason));continue
  g,_=gate(text);e=tok.encode(text);author=r.get('author','').strip().casefold();group=digest(['sdcnl_author',author]) if author not in ['','[deleted]'] else h
  meta.append(dict(source_id='sdcnl:test:'+str(i),text_hash=h,label=label,group_id=group,partition='sdcnl_authors_test',gate_v2=-1 if g is None else g));ids.append(e.ids);masks.append(e.attention_mask);texts.append(text)
 path=temp/'evaluation_inputs.npz';ids=np.array(ids,np.int64);masks=np.array(masks,np.int64)
 if path.exists():
  with np.load(path,allow_pickle=False) as old:assert np.array_equal(old['input_ids'],ids) and np.array_equal(old['attention_mask'],masks)
 else:np.savez_compressed(path,input_ids=ids,attention_mask=masks)
 (temp/'evaluation_texts.json').write_text(json.dumps(texts));freeze(root/'evaluation_metadata.json',meta);freeze(root/'evaluation_exclusions.json',excluded)
 return meta,path
