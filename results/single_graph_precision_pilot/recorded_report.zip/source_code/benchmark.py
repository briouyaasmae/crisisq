"""One live ORT graph per fresh process; full host hybrid pipeline timing."""
from pathlib import Path
import json,resource,sys,time
import numpy as np
import onnxruntime as ort
from tokenizers import Tokenizer
from common import sha,atomic,write_csv,gates
HERE=Path(__file__).resolve().parent

def memory():
 p=Path('/proc/self/smaps_rollup');pss=None
 if p.exists():pss=next((int(v.split()[1])/1024 for v in p.read_text().splitlines() if v.startswith('Pss:')),None)
 return dict(pss_mib=pss,peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024))
def run(job):
 assert ort.__version__==job['runtime'];assert sha(__file__)==job['worker_sha256'];assert sha(job['model_path'])==job['model_sha256']
 temp=Path(job['temporary_root']);assert sha(temp/'evaluation_texts.json')==job['texts_sha256'] and sha(temp/'tokenizer.json')==job['tokenizer_sha256'];texts=json.loads((temp/'evaluation_texts.json').read_text())
 tok=Tokenizer.from_file(str(temp/'tokenizer.json'));tok.enable_truncation(max_length=128);tok.enable_padding(length=128,pad_id=0,pad_token='[PAD]');gate=gates(json.loads((HERE/'frozen_rules.json').read_text()))
 with np.load(temp/'evaluation_inputs.npz',allow_pickle=False) as z:
  for i in job['indices']:
   e=tok.encode(texts[i]);assert np.array_equal(e.ids,z['input_ids'][i]) and np.array_equal(e.attention_mask,z['attention_mask'][i])
 options=ort.SessionOptions();options.intra_op_num_threads=4;options.inter_op_num_threads=1;options.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL;options.graph_optimization_level=ort.GraphOptimizationLevel.ORT_ENABLE_ALL;options.add_session_config_entry('session.intra_op.allow_spinning','0')
 start=time.perf_counter();session=ort.InferenceSession(job['model_path'],sess_options=options,providers=['CPUExecutionProvider']);init=1000*(time.perf_counter()-start);names={i.name for i in session.get_inputs()};assert names=={'input_ids','attention_mask'}
 def pipeline(i):
  g,_=gate(texts[i])
  if g is not None:return int(g),0
  e=tok.encode(texts[i]);feed=dict(input_ids=np.array([e.ids],np.int64),attention_mask=np.array([e.attention_mask],np.int64));z=np.asarray(session.run(None,feed)[0],float).reshape(-1);assert z.shape==(2,) and np.isfinite(z).all();z=np.exp(z-z.max());return int(z[1]/z.sum()>=job['tau']),1
 for i in job['indices'][:10]:pipeline(i)
 warm=memory();expected=dict(zip(job['indices'],job['expected_decisions']));records=[];wrong=0
 for i in np.random.default_rng(20261116+job['round']).permutation(job['indices']):
  i=int(i);start=time.perf_counter();pred,calls=pipeline(i);elapsed=1000*(time.perf_counter()-start);wrong+=int(pred!=expected[i]);records.append(dict(index=i,elapsed_ms=elapsed,prediction=pred,neural_calls=calls))
 out=Path(job['destination']);out.mkdir(parents=True,exist_ok=True);write_csv(out/'timing.csv',records);atomic(out/'complete.json',dict(complete=True,job_hash=__import__('common').digest(job),runtime=ort.__version__,graph_sessions=1,n=len(records),mean_ms=float(np.mean([r['elapsed_ms'] for r in records])),warm=warm,after=memory(),session_init_ms=init,live_vs_saved_disagreements=wrong,timing_sha256=sha(out/'timing.csv')))
if __name__=='__main__':run(json.loads(Path(sys.argv[1]).read_text()))
