import os
os.environ['MPLBACKEND']='Agg'
os.environ.pop('PYTHONPATH',None);os.environ.pop('PYTHONHOME',None)
from pathlib import Path
import csv,json,platform,random,shutil,statistics,subprocess,sys,traceback,zipfile
import numpy as np
from common import *
from search import assess,rank,feasible,choose
import environment,inputs
HERE=Path(__file__).resolve().parent
VERSIONS=['1.31.1','1.28.0']

def pack(root):
 target=root.with_name(root.name+'_reports.zip')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(root)))
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  assert not any(n.endswith(('.onnx','texts.json','testing-set.csv','full_evaluation_cases.jsonl','tokenizer.json')) for n in z.namelist())
 return target

def install(config,version):
 root=Path(config['output_root']);python=environment.ensure_environment(Path(config['temporary_root'])/('runtime_'+version));pkgs={'numpy':'2.1.3','onnxruntime':version,'tokenizers':'0.23.3'}
 if version=='1.31.1':pkgs.update(onnx='1.19.1',matplotlib='3.10.7')
 check=';'.join('import '+k+';assert '+k+'.__version__=='+repr(v) for k,v in pkgs.items())
 if subprocess.run([str(python),'-I','-c',check],capture_output=True).returncode:
  log=root/('install_'+version+'.log')
  with log.open('w') as f:result=subprocess.run(environment.pip_command(python,'install','--only-binary=:all:',*[k+'=='+v for k,v in pkgs.items()]),stdout=f,stderr=subprocess.STDOUT)
  if result.returncode:raise RuntimeError('Pinned wheels unavailable; no substitution. '+log.read_text()[-3000:])
 info=json.loads(subprocess.check_output([str(python),'-I','-c','import sys,json,onnxruntime as o,numpy;print(json.dumps(dict(runtime=o.__version__,numpy=numpy.__version__,build=o.get_build_info(),module=o.__file__,python=sys.version)))'],text=True));native=Path(info['module']).parent;info['native_hashes']={str(p.relative_to(native)):sha(p) for p in sorted(native.rglob('*.so'))};freeze(root/('runtime_'+version+'.json'),info)
 return python

class Study:
 def __init__(self,config):
  self.c=config;self.root=Path(config['output_root']);self.temp=Path(config['temporary_root']);self.root.mkdir(parents=True,exist_ok=True);self.temp.mkdir(parents=True,exist_ok=True)
  freeze(self.root/'configuration_frozen.json',config)
  freeze(self.root/'host_frozen.json',dict(platform=platform.platform(),machine=platform.machine(),cpu_count=os.cpu_count(),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip() if Path('/proc/sys/kernel/random/boot_id').exists() else None))
  code={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file()};self.protocol_hash=freeze(self.root/'implementation_frozen.json',code)
  source=self.root/'source_code';source.mkdir(exist_ok=True)
  for p in HERE.iterdir():
   if p.is_file():shutil.copy2(p,source/p.name)
  self.runtime={v:install(config,v) for v in VERSIONS};self.specs=self.root/'job_specs';self.specs.mkdir(exist_ok=True)
 def process(self,python,script,config,name):
  path=self.specs/(name+'.json');freeze(path,config);log=self.root/'logs'/(name+'.log');log.parent.mkdir(exist_ok=True)
  print(name,flush=True)
  with log.open('w') as f:result=subprocess.run([str(python),str(HERE/script),str(path)],stdout=f,stderr=subprocess.STDOUT)
  if result.returncode:raise RuntimeError(name+' failed: '+log.read_text()[-4000:])
 def graph(self,pair,groups):
  groups=sorted(groups);name=pair['id']+'__'+('regenerated_quantized' if not groups else digest(groups)[:16]);path=self.temp/'graphs'/(name+'.onnx');meta=self.root/'builds'/(name+'.json')
  if meta.exists() and path.exists():
   record=json.loads(meta.read_text());assert sha(path)==record['model_sha256']
  else:
   new=self.temp/(name+'_build.json');job=dict(id=name,groups=groups,fp32_path=pair['fp32']['path'],fp32_sha256=pair['fp32']['sha256'],output_path=str(path),metadata_path=str(new))
   self.process(self.runtime['1.31.1'],'build_graph.py',job,'build_'+name);record=json.loads(new.read_text());freeze(meta,record)
  return dict(id=name,path=str(path),sha256=record['model_sha256'],size_mb=record['size_mb'],groups=groups)
 def score(self,model,pair,phase,input_path,n):
  output={}
  for version in VERSIONS:
   name=phase+'__'+model['id']+'__'+version;dest=self.root/'scores'/name
   job=dict(id=name,runtime=version,model_path=model['path'],model_sha256=model['sha256'],inputs_path=str(input_path),inputs_sha256=sha(input_path),indices=list(range(n)),tau=pair['tau'],threads=4,optimization='ORT_ENABLE_ALL',output=str(dest),worker_sha256=sha(HERE/'inference_worker.py'),plan_hash=self.protocol_hash,require_isolated=True)
   done=dest/'complete.json'
   if done.exists():
    r=json.loads(done.read_text());assert r['job_identity']==digest(job) and sha(dest/'predictions.npz')==r['prediction_sha256']
   else:self.process(self.runtime[version],'inference_worker.py',job,name)
   check=json.loads(done.read_text());assert check['repeat_decision_changes']==0,'Within-session repeat decisions changed; investigate before selection/evaluation claims'
   with np.load(dest/'predictions.npz',allow_pickle=False) as z:output[version]=z['probabilities'].copy()
  return output
 def originals(self,pair):
  return {k:dict(id=pair['id']+'__'+k,**pair[k],size_mb=Path(pair[k]['path']).stat().st_size/1e6,groups=[]) for k in ['fp32','original_quantized']}
 def select(self,pair,meta,path):
  models=self.originals(pair);reference=self.score(models['fp32'],pair,'cal',path,len(meta));self.score(models['original_quantized'],pair,'cal',path,len(meta));base=self.graph(pair,[]);probs=self.score(base,pair,'cal',path,len(meta));gate=[r['gate_v2'] for r in meta]
  current=dict(id=base['id'],groups=[],**assess(probs,reference,gate,pair['tau'],base['size_mb']));records=[current];history=[];chosen=None
  inventory=self.temp/'inventory.json';job=dict(inventory_only=True,fp32_path=pair['fp32']['path'],fp32_sha256=pair['fp32']['sha256'],metadata_path=str(inventory));self.process(self.runtime['1.31.1'],'build_graph.py',job,'inventory');groups=sorted(json.loads(inventory.read_text())['groups']);freeze(self.root/'group_inventory.json',json.loads(inventory.read_text()))
  if feasible(current,self.c['size_limit_mb']):reason='regenerated_baseline_already_feasible'
  else:
   reason='bounded_search_exhausted'
   for stage in range(1,self.c['max_groups']+1):
    trials=[]
    for group in groups:
     if group in current['groups']:continue
     names=sorted(current['groups']+[group]);model=self.graph(pair,names)
     if model['size_mb']>self.c['size_limit_mb']:
      history.append(dict(stage=stage,id=model['id'],groups=names,size_mb=model['size_mb'],skipped='over_size_limit'));continue
     p=self.score(model,pair,'cal',path,len(meta));record=dict(id=model['id'],groups=names,**assess(p,reference,gate,pair['tau'],model['size_mb']));trials.append(record);records.append(record);history.append(dict(stage=stage,**record));atomic(self.root/'calibration_search_progress.json',history)
    winner,passed=choose(trials,current,self.c['size_limit_mb'])
    if winner is None:reason='no_strict_improvement';break
    current=winner
    if passed:chosen=winner;reason='calibration_constraints_met';break
  result=dict(accepted=chosen is not None,reason=reason,primary_model=pair['id'],tau=pair['tau'],groups=chosen['groups'] if chosen else [],candidate=chosen,classification_threshold_unchanged=True,objective='worst-runtime FP32-reference positive losses; total disagreements; cross-runtime disagreements; score MSE; labels excluded',constraints=dict(max_size_mb=self.c['size_limit_mb'],max_groups=self.c['max_groups'],required_calibration_reference_disagreements=0),calibration_metadata_hash=digest(meta),calibration_inputs_sha256=sha(path),evaluated_candidates=len(records),prior_inspection='Old runtime panel; historical label-stratified membership. New allocation uses only reference probabilities and gate outputs. Previously inspected evaluation corpora are not untouched tests.')
  freeze(self.root/'calibration_search.json',history);freeze(self.root/'selection_frozen.json',result)
  write_csv(self.root/'calibration_candidates.csv',[{**{k:v for k,v in r.items() if k not in ['per_runtime','groups']},'groups':'|'.join(r['groups'])} for r in records]);return result
 def evaluate(self,pairs,selected,meta,path):
  results=[];predictions={};evaluated=[]
  for pair in pairs:
   models=self.originals(pair);models['regenerated_quantized']=self.graph(pair,[]);models['selected_single_graph']=self.graph(pair,selected['groups']);models['head_only']=self.graph(pair,['classifier_head']);models['last_block']=self.graph(pair,['layer_5_attention','layer_5_ffn'])
   data={name:self.score(model,pair,'evaluation',path,len(meta)) for name,model in models.items()};predictions[pair['id']]={};gate=np.array([r['gate_v2'] for r in meta]);y=np.array([r['label'] for r in meta])
   for name,model in models.items():
    evaluated.append(dict(model=pair['id'],variant=name,**model));predictions[pair['id']][name]={}
    for version in VERSIONS:
     p=data[name][version];predictions[pair['id']][name][version]=decision(p,gate,pair['tau'])
     for mode in ['neural','hybrid']:
      g=gate if mode=='hybrid' else np.full(len(meta),-1);q=decision(p,g,pair['tau']);ref=decision(data['fp32'][version],g,pair['tau']);baseline=decision(data['original_quantized'][version],g,pair['tau'])
      for part in sorted({r['partition'] for r in meta}):
       ix=np.array([i for i,r in enumerate(meta) if r['partition']==part]);m=metric(y[ix],q[ix],ref[ix],baseline[ix]);lo,hi=group_delta(y[ix],baseline[ix],q[ix],[meta[i]['group_id'] for i in ix],True)
       results.append(dict(model=pair['id'],variant=name,runtime=version,mode=mode,partition=part,size_mb=model['size_mb'],**m,recall_delta_vs_original_quantized_ci_low=lo,recall_delta_vs_original_quantized_ci_high=hi))
  write_csv(self.root/'metrics.csv',results);freeze(self.root/'evaluation_models_frozen.json',evaluated)
  runtime=[]
  for pair in pairs:
   for name,values in predictions[pair['id']].items():
    for part in sorted({r['partition'] for r in meta}):
     ix=[i for i,r in enumerate(meta) if r['partition']==part];runtime.append(dict(model=pair['id'],variant=name,partition=part,n=len(ix),hybrid_cross_runtime_disagreements=int((values[VERSIONS[0]][ix]!=values[VERSIONS[1]][ix]).sum())))
  write_csv(self.root/'runtime_disagreements.csv',runtime)
  return predictions,evaluated
 def timing(self,pair,meta,predictions,evaluated):
  indices=[]
  for part in ['binary_test','sdcnl_authors_test']:
   pool=[i for i,r in enumerate(meta) if r['partition']==part];pool.sort(key=lambda i:digest(['single-graph-timing-v1',meta[i]['source_id']]));indices+=pool[:64]
  jobs=[]
  for round_number in range(3):
   row=[]
   for model in evaluated:
    if model['model']!=pair['id'] or model['variant']=='regenerated_quantized':continue
    for version in VERSIONS:
     name='timing__'+model['variant']+'__'+version+'__'+str(round_number);row.append(dict(id=name,runtime=version,variant=model['variant'],round=round_number,model_path=model['path'],model_sha256=model['sha256'],tau=pair['tau'],temporary_root=str(self.temp),destination=str(self.root/'timing'/name),indices=indices,expected_decisions=[int(predictions[pair['id']][model['variant']][version][i]) for i in indices],texts_sha256=sha(self.temp/'evaluation_texts.json'),tokenizer_sha256=sha(self.temp/'tokenizer.json'),worker_sha256=sha(HERE/'benchmark.py')))
   random.Random(20261116+round_number).shuffle(row);jobs+=row
  freeze(self.root/'timing_schedule_frozen.json',jobs);records=[]
  for job in jobs:
   done=Path(job['destination'])/'complete.json'
   if done.exists():
    r=json.loads(done.read_text());assert r['job_hash']==digest(job) and sha(Path(job['destination'])/'timing.csv')==r['timing_sha256']
   else:self.process(self.runtime[job['runtime']],'benchmark.py',job,job['id']);r=json.loads(done.read_text())
   records.append(dict(runtime=job['runtime'],variant=job['variant'],round=job['round'],mean_ms=r['mean_ms'],pss_mib=r['warm']['pss_mib'],peak_rss_mib=r['after']['peak_rss_mib'],live_vs_saved_disagreements=r['live_vs_saved_disagreements'],n=r['n']))
  write_csv(self.root/'timing_rounds.csv',records);summary=[]
  for version in VERSIONS:
   base=statistics.mean(r['mean_ms'] for r in records if r['runtime']==version and r['variant']=='fp32')
   for name in sorted({r['variant'] for r in records}):
    rr=[r for r in records if r['runtime']==version and r['variant']==name];mean=statistics.mean(r['mean_ms'] for r in rr);pss=[r['pss_mib'] for r in rr if r['pss_mib'] is not None];summary.append(dict(runtime=version,variant=name,mean_of_process_means_ms=mean,sd_of_process_means_ms=statistics.stdev(r['mean_ms'] for r in rr),speedup_vs_fp32=base/mean,mean_pss_mib=statistics.mean(pss) if pss else None,live_vs_saved_disagreements=sum(r['live_vs_saved_disagreements'] for r in rr),unique_messages=len(indices),process_rounds=3,scope='one-session host Python full pipeline; phone cost unmeasured'))
  write_csv(self.root/'timing_summary.csv',summary);return sum(r['live_vs_saved_disagreements'] for r in records)
 def export(self,pair,selected,calpath):
  model=self.graph(pair,selected['groups']);dest=self.root.with_name(self.root.name+'_phone_candidate.zip');manifest=dict(model='mixed_precision.onnx',sha256=model['sha256'],size_mb=model['size_mb'],source_fp32_sha256=pair['fp32']['sha256'],tau=pair['tau'],groups=selected['groups'],rules_sha256=sha(HERE/'frozen_rules.json'),tokenizer_sha256=sha(self.temp/'tokenizer.json'),max_length=128,scope='Calibration-selected research candidate. Check evaluation metrics first. Not an automatically compatible replacement for existing app manifests or original QUInt8 references. No phone speed claim.')
  atomic(self.root/'phone_candidate_manifest.json',manifest)
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
   z.write(model['path'],'mixed_precision.onnx');z.write(self.temp/'tokenizer.json','tokenizer.json');z.write(HERE/'frozen_rules.json','frozen_rules.json');z.write(self.root/'phone_candidate_manifest.json','manifest.json');z.write(self.root/'selection_frozen.json','selection_frozen.json');z.write(calpath,'calibration_parity_inputs.npz')
   for version in VERSIONS:z.write(self.root/'scores'/('cal__'+model['id']+'__'+version)/'predictions.npz','host_reference_'+version+'.npz')
   z.writestr('README.txt','Single-graph precision candidate, not a pretrained-weight update. Use the frozen tau and rules. Existing Flutter loaders/manifests and reference outputs must be updated for this new graph; original QUInt8 expected scores do not apply. Verify tokenizer IDs and numerical/device decision agreement before benchmarking. Then measure one-graph FP32, original QUInt8 and this graph under the same existing phone protocol. Do not infer phone speed or RAM from host timings. Calibration-reference agreement is not clinical correctness. Calibration token IDs may be sensitive; do not redistribute without source/license review.\n')
  with zipfile.ZipFile(dest) as z:assert z.testzip() is None
  return dest

def main(path):
 config=json.loads(Path(path).read_text());root=Path(config['output_root']);root.mkdir(parents=True,exist_ok=True)
 try:
  assert config['runtime_versions']==VERSIONS and config['model_scope'] in ['primary_only','fixed_extensions'];assert config['size_limit_mb']==100 and config['max_groups']==3 and config['timing_rounds']==3
  study=Study(config);pairs,coverage=inputs.discover(config);freeze(root/'model_coverage.json',coverage);freeze(root/'models_frozen.json',pairs);calmeta,calpath=inputs.calibration(config);selection=study.select(pairs[0],calmeta,calpath)
  if not selection['accepted']:
   (root/'KEY_FINDINGS.txt').write_text('Completed bounded calibration pilot: '+selection['reason']+'. No new mixed-precision allocation was selected under the fixed both-runtime agreement, 100 MB and 3-group protocol. Evaluation was not unlocked; do not select a near miss or tune the limits after reading results. A baseline-already-feasible outcome also provides no allocation benefit.\n');atomic(root/'completion.json',dict(complete=True,status='no_allocation_needed' if selection['reason']=='regenerated_baseline_already_feasible' else 'calibration_rejected',accepted=False,evaluation_run=False,phone_benefit_measured=False))
  else:
   meta,evalpath=inputs.evaluation(config);predictions,models=study.evaluate(pairs,selection,meta,evalpath);mismatch=study.timing(pairs[0],meta,predictions,models);candidate=study.export(pairs[0],selection,calpath)
   subprocess.run([str(study.runtime['1.31.1']),str(HERE/'summarize.py'),str(root)],check=True)
   atomic(root/'completion.json',dict(complete=True,status='evaluation_complete',accepted=True,evaluation_cases=len(meta),checkpoint_pairs=len(pairs),timing_live_vs_saved_disagreements=mismatch,classification_thresholds_unchanged=True,clinical_or_untouched_validation=False,phone_benefit_measured=False,phone_candidate_archive=str(candidate)))
  failure=root/'failure.json'
  if failure.exists():
   archived=root/'resolved_failures';archived.mkdir(exist_ok=True);failure.replace(archived/(sha(failure)+'.json'))
  files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts];(root/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(root))+'\n' for p in files));print('COMPLETE. Return:',pack(root),flush=True)
 except Exception as error:
  atomic(root/'failure.json',dict(complete=False,error_type=type(error).__name__,message=str(error),traceback=traceback.format_exc()));print('INCOMPLETE diagnostic report:',pack(root),flush=True);raise
if __name__=='__main__':main(sys.argv[1])
