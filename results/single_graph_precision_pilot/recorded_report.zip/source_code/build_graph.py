"""Single-graph QUInt8 allocation. No training; exact restored-weight checks."""
from pathlib import Path
import argparse,copy,json,re,shutil
import numpy as np
import onnx,onnxruntime as ort
from onnx import numpy_helper
from onnxruntime.quantization import quantize_dynamic,QuantType
from onnxruntime.quantization.onnx_model import ONNXModel
from common import sha,atomic,digest

def inventory(path):
 model=ONNXModel(onnx.load(str(path)));model.replace_gemm_with_matmul();graph=model.model
 initial={x.name:x for x in graph.graph.initializer};groups={}
 for node in graph.graph.node:
  if node.op_type!='MatMul' or len(node.input)<2 or node.input[1] not in initial:continue
  match=re.search(r'/layer\.(\d+)/(attention|ffn)/',node.name)
  if match:group='layer_'+match.group(1)+'_'+match.group(2)
  elif '/pre_classifier/' in node.name or '/classifier/' in node.name:group='classifier_head'
  else:raise RuntimeError('Unrecognized weighted MatMul: '+node.name)
  w=initial[node.input[1]];a=numpy_helper.to_array(w)
  groups.setdefault(group,[]).append(dict(name=node.name,weight=node.input[1],shape=list(a.shape),fp32_bytes=int(a.nbytes),weight_sha256=__import__('hashlib').sha256(a.tobytes()).hexdigest()))
 assert len(groups)==13 and sum(len(v) for v in groups.values())==38,'Unexpected DistilBERT graph; stop rather than change the search.'
 return graph,groups

def build(config):
 assert ort.__version__=='1.31.1' and onnx.__version__=='1.19.1'
 source=Path(config['fp32_path']);assert sha(source)==config['fp32_sha256'];base,groups=inventory(source)
 if config.get('inventory_only'):
  atomic(config['metadata_path'],dict(groups=groups,fp32_sha256=sha(source),onnx=onnx.__version__,quantizer=ort.__version__));return
 names=sorted(n['name'] for group in config['groups'] for n in groups[group]);output=Path(config['output_path']);output.parent.mkdir(parents=True,exist_ok=True)
 # ORT path-based shape inference writes <model>-inferred.onnx beside its
 # input. Mounted Kaggle inputs are read-only: quantize a verified local copy.
 # Cache one copy per source hash (not per candidate) to bound disk use.
 local=output.parent/'_fp32_sources'/config['fp32_sha256']/'fp32.onnx'
 local.parent.mkdir(parents=True,exist_ok=True)
 if not local.exists():
  partial=local.with_suffix('.copying.onnx');shutil.copyfile(source,partial)
  assert sha(partial)==config['fp32_sha256'],'Temporary source copy differs'
  partial.replace(local)
 assert sha(local)==config['fp32_sha256'],'Cached FP32 source differs'
 tmp=output.with_suffix('.partial.onnx')
 quantize_dynamic(str(local),str(tmp),weight_type=QuantType.QUInt8,nodes_to_exclude=names)
 model=onnx.load(str(tmp));onnx.checker.check_model(model);actual={n.name:n for n in model.graph.node};initial={w.name:w for w in model.graph.initializer};orig_initial={w.name:w for w in base.graph.initializer};checks=[]
 for group,records in groups.items():
  for record in records:
   name=record['name']
   if group in config['groups']:
    node=actual.get(name);assert node is not None and node.op_type=='MatMul','Exclusion not implemented: '+name
    assert node.input[1] in initial;assert np.array_equal(numpy_helper.to_array(initial[node.input[1]]),numpy_helper.to_array(orig_initial[record['weight']])), 'Restored weight differs: '+name
    checks.append(dict(name=name,precision='float32',verified=True))
   else:
    node=actual.get(name+'_quant');assert node is not None and node.op_type=='MatMulInteger','Expected quantized node missing: '+name
    checks.append(dict(name=name,precision='uint8',verified=True))
 assert sha(source)==config['fp32_sha256'],'Original checkpoint changed'
 assert sha(local)==config['fp32_sha256'],'Temporary source changed'
 tmp.replace(output)
 atomic(config['metadata_path'],dict(id=config['id'],groups=config['groups'],excluded_nodes=names,node_checks=checks,source_sha256=sha(source),model_sha256=sha(output),size_mb=output.stat().st_size/1e6,onnx=onnx.__version__,quantizer=ort.__version__,recipe='quantize_dynamic; QUInt8; original defaults; selected weighted MatMuls excluded; no training',classifiers_and_embeddings='Classifier head is a separate group; embeddings retain the ordinary QUInt8 recipe.'))
 print('BUILT',config['id'],len(names),'restored MatMuls',output.stat().st_size/1e6,'MB',flush=True)
if __name__=='__main__':build(json.loads(Path(__import__('sys').argv[1]).read_text()))
