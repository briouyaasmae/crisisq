Device replay handoff: ordered int64 inputs and matched-host reference outputs.
The models remain the exact existing frozen graphs; they are not duplicated here.
The published Flutter app has strict frozen manifests. Do not overwrite those
assets with this diagnostic matrix or treat its old reference checks as new
factorial evidence. A separate native/app harness must implement the declared
session options before recording new matched physical-device results. This
packet is preparation for that follow-up, not an executable phone application
or proof that a host setting fixes Android/iOS. Tokenized research data retain
original source terms; lack of raw text is not a claim of anonymization.
