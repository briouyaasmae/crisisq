CrisisQ controlled runtime matrix — completed fixed suite
{
  "all_jobs_complete": true,
  "plan_hash": "2e92d62514d69c0ba92d110c2be164194bf749da56cc21dd241d2d5c9d1929e2",
  "jobs": 448,
  "models": 28,
  "settings": 16,
  "available_joint_pairs": 7,
  "primary_messages": 1700,
  "multiseed_panel_messages": 256,
  "new_training_runs": 0,
  "new_threshold_searches": 0,
  "new_independent_datasets": 0,
  "host_machine": "x86_64",
  "repeatability_failures": 0
}

Interpretation rules:
All inputs are the previously inspected frozen Twitter messages. This is not a new independent dataset.
Version contrasts hold observed host, NumPy, inputs, graph bytes, threshold, optimizer and threads fixed; runtime wheel builds still differ.
An optimizer contrast identifies a tested setting effect, not a uniquely responsible operator.
Historical Android endpoints are not a new controlled phone-runtime matrix. CPU/OS/build differences remain.
The empirical min/max envelope covers only completed settings on this host. It is not certification for unseen devices or inputs.
Stress outputs are alert rates on keyword-enriched source-negative messages; source labels are unaudited.
Host one-pass timings are descriptive, not comparable to the published Flutter pipeline timing protocol.
No result is selected to replace the frozen primary model. Null and adverse results remain reported.

saqs__42__fp32: observed decision differences against historical Android range 0–0 across the declared host settings. This is descriptive, not a verified phone fix.

saqs__42__q_quint8: observed decision differences against historical Android range 6–17 across the declared host settings. This is descriptive, not a verified phone fix.
