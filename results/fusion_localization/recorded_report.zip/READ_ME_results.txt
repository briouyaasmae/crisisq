All fixed jobs completed and output identities verified.
Read fusion_contrasts.csv first; then operator_count_deltas.csv and graph_inventory.json.
A requested disable with unchanged graph is inconclusive. Graph fingerprints retain names and wiring: inspect operator deltas before claiming fusion removal.
A changed graph with unchanged decisions may still change probabilities. Recovery toward BASIC is not evidence BASIC is more accurate.
A successful single-family intervention localizes an optimization pathway on this host, not a unique defective kernel or a phone fix. Interacting downstream rewrites can change too.
One seed, one backbone, already-inspected source data, CPU only. No new dataset, fitting, retraining, or clinical validation.
Saved optimized graph replay was checked on the fixed first 16 inputs per job; repeatability on another deterministic 16. These checks are not full independent replays.
The main intervention uses all 1700 inputs, including unchanged cases; there is no selection of favorable messages.
