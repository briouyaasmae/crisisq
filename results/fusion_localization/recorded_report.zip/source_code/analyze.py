from pathlib import Path
import csv,json,hashlib,zipfile
import numpy as np

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
def csvwrite(p,rows):
    if not rows:return
    with Path(p).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def pack(root):
    root=Path(root);dest=root.parent/(root.name+'_reports.zip')
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.suffix not in ['.onnx','.partial'] and p.name!='checkpoint.npz':z.write(p,str(p.relative_to(root)))
    return dest
TARGETS={'DynamicQuantizeMatMulFusion':'com.microsoft::DynamicQuantizeMatMul','MatMulIntegerToFloatFusion':'com.microsoft::MatMulIntegerToFloat','AttentionFusion':'com.microsoft::Attention','GeluFusion':'com.microsoft::Gelu','BiasGeluFusion':'com.microsoft::BiasGelu','LayerNormFusion':'ai.onnx::LayerNormalization','SkipLayerNormFusion':'com.microsoft::SkipLayerNormalization'}
def main(root):
    root=Path(root);jobs=json.loads((root/'jobs_frozen.json').read_text());plan=json.loads((root/'protocol_frozen.json').read_text())
    cases=json.loads((root/'preparation/case_metadata.json').read_text());loaded={};graphs={}
    for j in jobs:
        d=Path(j['output']);c=json.loads((d/'complete.json').read_text())
        assert c['complete'] and c['job_identity']==digest(j) and c['plan_hash']==plan['plan_hash']
        assert c['prediction_sha256']==sha(d/'predictions.npz') and c['graph_inventory_sha256']==sha(d/'graph_inventory.json')
        assert c['repeat_decision_changes']==0 and c['repeat_max_probability_difference']<=1e-5,'Repeat instability: investigate before interpreting'
        assert c['graph_replay_max_logit_difference']>=0
        with np.load(d/'predictions.npz',allow_pickle=False) as a:
            assert list(a['indices'])==j['indices'];loaded[j['id']]=a['probabilities'].copy()
        graphs[j['id']]=json.loads((d/'graph_inventory.json').read_text())
    contrasts=[];details=[];outcomes=[];operator_rows=[]
    def find(j,name):return next(k for k in jobs if k['model_id']==j['model_id'] and k['runtime']==j['runtime'] and k['name']==name)
    for j in jobs:
        p=loaded[j['id']];e=find(j,'extended');b=find(j,'basic');ep=loaded[e['id']];bp=loaded[b['id']];g=graphs[j['id']];eg=graphs[e['id']]
        decision=p>=j['tau'];ed=ep>=j['tau'];bd=bp>=j['tau'];gate=np.array([cases[i]['gate_v2'] for i in j['indices']]);label=np.array([cases[i]['label'] for i in j['indices']]);parts=np.array([cases[i]['partition'] for i in j['indices']]);hybrid=np.where(gate==-1,decision,gate==1)
        graph_changed=g['graph_fingerprint']!=eg['graph_fingerprint'];op_changed=g['operator_counts']!=eg['operator_counts']
        targets=[TARGETS[x] for x in j['disabled_optimizers'] if x in TARGETS]
        target_reduced=any(g['operator_counts'].get(op,0)<eg['operator_counts'].get(op,0) for op in targets)
        if not j['disabled_optimizers']:status='baseline'
        elif not graph_changed:status='no observed graph change; ablation unverified'
        elif not op_changed:status='graph changed; operator counts unchanged; inspect wiring/attributes'
        elif target_reduced:status='expected fused operator count reduced; inspect numerical consequence'
        else:status='operator graph changed; requested target not established'
        contrasts.append(dict(model=j['model_id'],runtime=j['runtime'],profile=j['name'],disabled='|'.join(j['disabled_optimizers']),n=len(p),graph_changed_vs_extended=graph_changed,operator_counts_changed_vs_extended=op_changed,expected_fused_operator_reduced=target_reduced,interpretation=status,max_probability_delta_vs_extended=float(np.max(np.abs(p-ep))),max_probability_delta_vs_basic=float(np.max(np.abs(p-bp))),probabilities_not_close_vs_extended=int(np.sum(~np.isclose(p,ep,atol=1e-5,rtol=1e-5))),neural_decisions_changed_vs_extended=int(np.sum(decision!=ed)),hybrid_decisions_changed_vs_extended=int(np.sum((decision!=ed)&(gate==-1))),neural_disagreements_vs_basic=int(np.sum(decision!=bd)),baseline_basic_extended_disagreements=int(np.sum(bd!=ed)),basic_extended_disagreements_recovered=int(np.sum((bd!=ed)&(decision==bd))),new_disagreements_with_basic=int(np.sum((bd==ed)&(decision!=bd))),graph_nodes=g['node_count']))
        for op in sorted(set(g['operator_counts'])|set(eg['operator_counts'])):
            operator_rows.append(dict(model=j['model_id'],runtime=j['runtime'],profile=j['name'],operator=op,count=g['operator_counts'].get(op,0),extended_count=eg['operator_counts'].get(op,0),delta=g['operator_counts'].get(op,0)-eg['operator_counts'].get(op,0)))
        for part in sorted(set(parts)):
            for mode,pred in [('neural',decision),('hybrid',hybrid)]:
                m=parts==part;pos=m&(label==1);neg=m&(label==0)
                outcomes.append(dict(model=j['model_id'],runtime=j['runtime'],profile=j['name'],partition=part,mode=mode,n=int(sum(m)),source_positives=int(sum(pos)),source_negatives=int(sum(neg)),missed_source_positives=int(sum(pos&~pred)),alerts_on_source_negatives=int(sum(neg&pred)),recall=float(np.mean(pred[pos])) if sum(pos) else '',source_negative_alert_rate=float(np.mean(pred[neg])) if sum(neg) else '',label_note='Keyword-enriched source-negative partition: alerts, not adjudicated false positives'))
        for k in np.flatnonzero((decision!=ed)|(decision!=bd)):
            c=cases[j['indices'][k]]
            details.append(dict(model=j['model_id'],runtime=j['runtime'],profile=j['name'],source_id=c['source_id'],text_hash=c['text_hash'],partition=c['partition'],source_label=c['label'],gate=c['gate_v2'],tau=j['tau'],p_basic=float(bp[k]),p_extended=float(ep[k]),p_profile=float(p[k]),decision_basic=int(bd[k]),decision_extended=int(ed[k]),decision_profile=int(decision[k])))
    csvwrite(root/'fusion_contrasts.csv',contrasts);csvwrite(root/'operator_count_deltas.csv',operator_rows);csvwrite(root/'decision_changes.csv',details);csvwrite(root/'source_label_outcomes.csv',outcomes)
    runtime=[]
    for j in jobs:
        if j['runtime']!='1.28.0':continue
        other=next(k for k in jobs if k['model_id']==j['model_id'] and k['name']==j['name'] and k['runtime']=='1.31.1')
        a=loaded[j['id']];b=loaded[other['id']];gate=np.array([cases[i]['gate_v2'] for i in j['indices']]);flip=(a>=j['tau'])!=(b>=j['tau'])
        runtime.append(dict(model=j['model_id'],profile=j['name'],max_probability_delta=float(np.max(abs(a-b))),neural_decision_differences=int(sum(flip)),hybrid_decision_differences=int(sum(flip&(gate==-1)))))
    csvwrite(root/'matched_runtime_contrasts.csv',runtime)
    text='''All fixed jobs completed and output identities verified.\nRead fusion_contrasts.csv first; then operator_count_deltas.csv and graph_inventory.json.\nA requested disable with unchanged graph is inconclusive. Graph fingerprints retain names and wiring: inspect operator deltas before claiming fusion removal.\nA changed graph with unchanged decisions may still change probabilities. Recovery toward BASIC is not evidence BASIC is more accurate.\nA successful single-family intervention localizes an optimization pathway on this host, not a unique defective kernel or a phone fix. Interacting downstream rewrites can change too.\nOne seed, one backbone, already-inspected source data, CPU only. No new dataset, fitting, retraining, or clinical validation.\nSaved optimized graph replay was checked on the fixed first 16 inputs per job; repeatability on another deterministic 16. These checks are not full independent replays.\nThe main intervention uses all 1700 inputs, including unchanged cases; there is no selection of favorable messages.\n'''
    (root/'READ_ME_results.txt').write_text(text)
    failure=root/'failure.json'
    if failure.exists():failure.unlink()
    result=dict(all_jobs_complete=True,jobs=len(jobs),plan_hash=plan['plan_hash']);(root/'completion.json').write_text(json.dumps(result,indent=2));pack(root)
    return result
