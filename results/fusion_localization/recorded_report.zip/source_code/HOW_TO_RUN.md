# CrisisQ fusion/operator-family localization v1
Import CrisisQ_fusion_operator_localization_v1.ipynb into Kaggle. Internet ON; CPU is sufficient.
Attach the SAME complete model-containing output used for the runtime matrix: CrisisQ_nonclinical_claim_verification output (crisisq_nonclinical_v1_compat/models/saqs__42). Do not attach only a reports ZIP. No new input ZIP is required.
The notebook finds fp32.onnx and q_quint8.onnx by exact hashes under /kaggle/input. If an exact full_evaluation_cases.jsonl is missing, it reconstructs the same frozen source/token packet from the pinned public source and embedded membership recipe.
Run All. 28 fixed jobs, primary SAQS seed42 only: QUInt8 has BASIC, EXTENDED and 10 disabled-family profiles in each of two runtimes; FP32 has BASIC/EXTENDED controls. Each job uses all1700 cases. Plan for a substantial CPU run, shorter than the previous448-job matrix; duration depends on host.
No training, model download, quantization, new thresholds, annotation or new dataset.
Return crisisq_fusion_operator_localization_v1_reports.zip from /kaggle/working. Failed/no-op requests stay visible.
Temporary optimized graphs are inspected and replayed, then deleted; reports preserve their graph structure/attribute/constant hashes and operator counts, not weights or raw text.
A fusion family can be implicated only when an actual operator-graph change accompanies a numerical effect. This is not guaranteed to identify a unique kernel or fix an iPhone. BASIC recovery does not mean increased accuracy.
The experiment is informed by previously observed results, not preregistered or independent evaluation. Keep all profiles including no-ops. First16 inputs/job check optimized export replay; another deterministic16 check within-session repeatability.
Resume only on the unchanged host/session, same configuration and files. A changed host requires new output AND temporary folders. Protocol hashes prevent mixing.
