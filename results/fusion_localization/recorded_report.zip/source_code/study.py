"""Predeclared primary-pair fusion family interventions; no fitting."""
from pathlib import Path
import json,sys,subprocess,random
sys.path.insert(0,str(Path(__file__).resolve().parent))
import base_study as base
sha=base.sha;digest=base.digest;atomic=base.atomic
FAMILIES=[['DynamicQuantizeMatMulFusion'],['MatMulIntegerToFloatFusion'],['DynamicQuantizeMatMulFusion','MatMulIntegerToFloatFusion'],['AttentionFusion'],['GeluFusion'],['BiasGeluFusion'],['LayerNormFusion'],['SkipLayerNormFusion'],['MatMulScaleFusion'],['MatMulAddFusion']]
def prepare(config):
    root=Path(config['output_root']);root.mkdir(parents=True,exist_ok=True)
    code=root/'source_code';code.mkdir(exist_ok=True)
    for source in Path(__file__).parent.iterdir():
        if source.is_file() and source.suffix in ['.py','.md']:(code/source.name).write_bytes(source.read_bytes())
    baseconfig=dict(config,model_scope='primary_only',optimization_levels=['ORT_ENABLE_ALL'],threads=[4])
    protocol,oldjobs=base.prepare(baseconfig,root/'preparation')
    models=protocol['models'];profiles=[dict(name='basic',optimization='ORT_ENABLE_BASIC',disabled_optimizers=[]),dict(name='extended',optimization='ORT_ENABLE_EXTENDED',disabled_optimizers=[])]
    profiles += [dict(name='disable_'+'__'.join(x),optimization='ORT_ENABLE_EXTENDED',disabled_optimizers=x) for x in FAMILIES]
    hashes={n:sha(Path(__file__).with_name(n)) for n in ['study.py','base_study.py','worker.py','analyze.py','graph_audit.py','environment.py','build_full_device_packet.py']}
    plan=dict(version='crisisq_fusion_operator_localization_v1',config=config,models=models,profiles=profiles,parent_preparation_plan=json.loads((root/'preparation/protocol_frozen.json').read_text())['plan_hash'],implementation_hashes=hashes,system=protocol['system'],scope='post-hoc primary SAQS seed42 only; already inspected 1700 messages; no independent dataset or multiseed claim',runtime_versions=config['runtime_versions'],threads=4,selection_hash=protocol['selection_hash'],packet_sha256=protocol['packet_sha256'],interpretation='A disable request alone is not evidence. Require graph/operator change and numerical consequence. Single transformer changes can affect downstream transformations; no unique kernel causation claim.')
    h=digest(plan);f=root/'protocol_frozen.json'
    if f.exists():assert json.loads(f.read_text())['plan_hash']==h,'Plan or host changed: use new output and temporary folders'
    else:atomic(f,dict(plan_hash=h,protocol=plan))
    jobs=[]
    for model in models:
        for version in config['runtime_versions']:
            for profile in profiles:
                if model['variant']=='fp32' and profile['disabled_optimizers']:continue
                old=next(j for j in oldjobs if j['model_id']==model['id'] and j['runtime']==version)
                key=model['id']+'__'+version+'__'+profile['name']
                job=dict(old,id=key,plan_hash=h,worker_sha256=hashes['worker.py'],output=str(root/'jobs'/key),graph_path=str(Path(config['temporary_root'])/'optimized_graphs'/('current.onnx')),**profile)
                jobs.append(job)
    # Baselines first; both runtimes and all fixed candidates are retained.
    jobs.sort(key=lambda j:(bool(j['disabled_optimizers']),j['model_id'],j['runtime'],j['name']))
    atomic(root/'jobs_frozen.json',jobs)
    print('Frozen:',h,';',len(jobs),'jobs; all 1700 messages per job',flush=True)
    return jobs

def install(config,root):
    # base installer pins NumPy and records native hashes; add ONNX before recording freeze.
    env=base.load_module(Path(__file__).with_name('environment.py'),'envtools');results={}
    for version in config['runtime_versions']:
        python=env.ensure_environment(Path(config['temporary_root'])/('ort_'+version))
        probe=subprocess.run([str(python),'-I','-c','import onnx,onnxruntime,numpy;assert onnx.__version__=="1.19.1" and onnxruntime.__version__=="'+version+'" and numpy.__version__=="2.1.3"'],capture_output=True,text=True)
        if probe.returncode:
            log=Path(root)/('install_fusion_'+version+'.log')
            with log.open('w') as f:
                status=subprocess.run(env.pip_command(python,'install','--only-binary=:all:',f'onnxruntime=={version}','numpy==2.1.3','onnx==1.19.1'),stdout=f,stderr=subprocess.STDOUT)
            if status.returncode:raise RuntimeError('Pinned wheel installation failed: '+str(log)+'\n'+log.read_text()[-2000:])
    return base.install_environments(config,root)

def execute(config,root,jobs,environments):
    # base executor calls sibling worker.py and validates output identities/hashes.
    return base.execute(config,root,jobs,environments)
if __name__=='__main__':
    prepare(json.loads(Path(sys.argv[1]).read_text()))
