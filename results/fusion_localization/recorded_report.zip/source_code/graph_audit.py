"""Inventory retains graph structure and constant hashes, never model weights."""
import hashlib,json,collections
from pathlib import Path
import onnx

def inventory(path):
    model=onnx.load(str(path),load_external_data=True)
    records=[];counts=collections.Counter()
    # Order-insensitive records avoid attributing a mere topological reordering to a rewrite.
    # Wiring/names are retained: this is a conservative structural fingerprint, not graph isomorphism.
    for n in model.graph.node:
        op=(n.domain or 'ai.onnx')+'::'+n.op_type;counts[op]+=1
        records.append(dict(op=op,inputs=list(n.input),outputs=list(n.output),attributes=sorted((a.name,hashlib.sha256(a.SerializeToString(deterministic=True)).hexdigest()) for a in n.attribute)))
    records.sort(key=lambda r:json.dumps(r,sort_keys=True))
    constants=sorted((t.name,hashlib.sha256(t.SerializeToString(deterministic=True)).hexdigest()) for t in model.graph.initializer)
    structure=dict(nodes=records,initializers=constants,inputs=[v.SerializeToString(deterministic=True).hex() for v in model.graph.input],outputs=[v.SerializeToString(deterministic=True).hex() for v in model.graph.output])
    return dict(graph_fingerprint=hashlib.sha256(json.dumps(structure,sort_keys=True).encode()).hexdigest(),node_count=len(records),operator_counts=dict(sorted(counts.items())),nodes=records,initializer_hashes=constants,onnx_version=onnx.__version__,opsets=[(x.domain,x.version) for x in model.opset_import],fingerprint_note='Conservative graph structure, wiring, attributes and constant hashes; excludes producer metadata and node order. Renaming alone can change fingerprint.')
