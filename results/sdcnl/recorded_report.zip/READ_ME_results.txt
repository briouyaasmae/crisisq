SDCNL evaluation complete. Primary panel: authors_test_clean_primary.
Read metrics.csv, paired_decision_effects.csv, dataset_summary.json and overlap_coverage.json.
Labels denote SuicideWatch/depression subreddit membership. Recall/precision/F1 are against those source labels. Alerts on depression posts are not adjudicated false positives.
All-post and raw panels are sensitivity analyses sharing messages, not independent confirmations. Original SDCNL train/test labels were never used to train or select CrisisQ in this notebook.
Known overlap exclusions do not prove training independence: unavailable original training membership and near duplicates remain unresolved.
Gate sees the full title/body, neural model sees first128 tokens. Token lengths and truncation are reported. Frozen behavior is not altered for this dataset.
Post-level metrics have author-cluster percentile intervals. CE/SAQS intervals resample jointly accepted available seed pairs; selection can bias the arm comparison. No seed pooling as independent messages.
Runtime is fixed at ORT1.31.1/ALL/4 CPU threads. Results are specific to that environment and are not phone measurements.
No retraining, threshold search, new annotation or clinical validation. Reports exclude original posts, titles, author strings and URLs.
