"""Pinned SDCNL source-label evaluation. No fitting or training."""
from pathlib import Path
import base64,collections,csv,gzip,hashlib,html,io,json,math,os,platform,re,subprocess,sys,time,unicodedata,urllib.request
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import environment
HERE=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,default=str).encode()).hexdigest()
def atomic(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.partial');t.write_text(json.dumps(x,indent=2));t.replace(p)
def normal(t):return re.sub(r'\s+',' ',re.sub(r'[^\w\s]',' ',unicodedata.normalize('NFKC',html.unescape(str(t))).casefold().replace('\u2019',"'"))).strip()
def text_hash(t):return hashlib.sha256(normal(t).encode()).hexdigest()
def download(record,path):
 path=Path(path)
 if path.exists():assert sha(path)==record['sha256'];return path.read_bytes()
 for attempt in range(3):
  try:
   data=urllib.request.urlopen(urllib.request.Request(record['url'],headers={'User-Agent':'CrisisQ-SDCNL-frozen-evaluation'}),timeout=120).read()
   assert hashlib.sha256(data).hexdigest()==record['sha256'],'Pinned source checksum differs'
   path.write_bytes(data);return data
  except Exception:
   if attempt==2:raise
   time.sleep(2)
def gate_function(rules):
 # Execute only the locally embedded, hash-frozen source from the already-used rules artifact.
 scope={'re':re,'_C':[(a,b,re.compile(c)) for a,b,c in rules['crisis']],'_S':[(a,b,re.compile(c)) for a,b,c in rules['safe']],'V2_NEGATORS':set(rules['negators']),'V2_CONTRAST':re.compile(rules['contrast']),'V2_RISK_CUES':re.compile(rules['risk'])}
 exec(rules['source'],scope)
 return scope['stage1_v2']
def prepare(config):
 from tokenizers import Tokenizer
 import tokenizers
 assert tokenizers.__version__=='0.23.3'
 root=Path(config['output_root']);root.mkdir(parents=True,exist_ok=True);temp=Path(config['temporary_root']);temp.mkdir(parents=True,exist_ok=True)
 source=json.loads((HERE/'source_manifest.json').read_text());public={}
 for name,record in source['files'].items():
  data=download(record,temp/name);rows=list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))));assert len(rows)==record['rows'];public[name]=rows
 # Verify the published combined file is exactly the union of the authors' split files.
 def key(r):return digest([r['title'],r['selftext'],int(r['is_suicide']),r['url']])
 assert collections.Counter(map(key,public['combined-set.csv']))==collections.Counter(map(key,public['training-set.csv']+public['testing-set.csv']))
 testkeys=set(map(key,public['testing-set.csv']));trainkeys=set(map(key,public['training-set.csv']))
 rules=json.loads((HERE/'frozen_rules.json').read_text());gate=gate_function(rules)
 seed=json.loads(gzip.decompress((HERE/'full_evaluation_seed.json.gz').read_bytes()));external=json.loads((HERE/'external_frozen.json').read_text());selection=json.loads((HERE/'selection_frozen.json').read_text())
 known={r['text_hash'] for r in seed['labeled_rows']}
 # Hash indexes already present in the mounted outputs can extend known exact overlaps.
 candidates=set();coverage=[]
 for pattern in ['*.csv','*.jsonl','*.parquet']:
  candidates.update(Path(config['input_root']).rglob(pattern))
 for path in sorted(candidates):
  rec=dict(path=str(path),bytes=path.stat().st_size,matched_text_rows=0,status='not inspected',training_membership='not established; file names are not proof')
  if path.suffix=='.parquet':rec['status']='not inspected: parquet unsupported';coverage.append(rec);continue
  if path.stat().st_size>256*1024*1024:rec['status']='not inspected: exceeds256MiB';coverage.append(rec);continue
  try:
   count=0
   with path.open(encoding='utf-8-sig',newline='') as f:
    iterable=csv.DictReader(f) if path.suffix=='.csv' else (json.loads(line) for line in f if line.strip())
    for row in iterable:
     if not isinstance(row,dict):continue
     count+=1
     if isinstance(row.get('text_hash'),str) and re.fullmatch('[0-9a-f]{64}',row['text_hash']):known.add(row['text_hash'])
     lower={str(k).lower():v for k,v in row.items()}
     texts=[lower[k] for k in ['text','tweet','selftext','body','post','content'] if isinstance(lower.get(k),str) and lower[k].strip()]
     if isinstance(lower.get('title'),str) and isinstance(lower.get('selftext'),str):texts.append(lower['title'].strip()+'\n\n'+lower['selftext'].strip())
     for value in texts:known.add(text_hash(value));rec['matched_text_rows']+=1
   rec.update(status='inspected recognized text/text_hash fields; no near-duplicate test',rows=count,sha256=sha(path))
  except Exception as e:rec.update(status='incomplete inspection: '+type(e).__name__)
  coverage.append(rec)
 atomic(root/'overlap_coverage.json',dict(files=coverage,known_normalized_hashes=len(known),historical_training_overlap='NOT CERTIFIED: original training membership/texts may be absent; exact checks do not exclude near duplicates'))
 rows=[]
 for number,r in enumerate(public['combined-set.csv']):
  assert r['is_suicide'] in ['0','1'];title=r['title'].strip();body=r['selftext'].strip();text=title+'\n\n'+body
  value=text_hash(text);body_hash=text_hash(body);g,reason=gate(text)
  rows.append(dict(source_id='sdcnl:'+str(number),text_hash=value,body_hash=body_hash,label=int(r['is_suicide']),author_group=digest(r['author'].strip().casefold()) if r['author'].strip() not in ['','[deleted]'] else value,authors_test=key(r) in testkeys,authors_train=key(r) in trainkeys,known_exact_overlap=value in known or body_hash in known,gate_v2=-1 if g is None else g,gate_reason=reason,empty_or_removed=not normal(text) or normal(body) in ['removed','deleted',''],text=text))
 groups=collections.defaultdict(list)
 for i,r in enumerate(rows):groups[r['text_hash']].append(i)
 for ix in groups.values():
  conflict=len({rows[i]['label'] for i in ix})>1
  # Prefer the authors' test representative when an exact duplicate spans both source splits.
  rep=min(ix,key=lambda i:(not rows[i]['authors_test'],i))
  for i in ix:rows[i].update(label_conflict=conflict,duplicate_representative=i==rep,source_duplicate_count=len(ix),authors_test=any(rows[k]['authors_test'] for k in ix))
 for r in rows:r['clean_eligible']=not(r['known_exact_overlap'] or r['label_conflict'] or r['empty_or_removed']) and r['duplicate_representative']
 tokenizer_bytes=base64.b64decode(seed['tokenizer_base64']);assert hashlib.sha256(tokenizer_bytes).hexdigest()==seed['model_hashes']['tokenizer.json']
 tok=Tokenizer.from_str(tokenizer_bytes.decode());tok.no_truncation();tok.no_padding()
 lengths=[len(tok.encode(r['text']).ids) for r in rows];tok.enable_truncation(max_length=128);tok.enable_padding(length=128,pad_id=0,pad_token='[PAD]')
 enc=tok.encode_batch([r['text'] for r in rows]);ids=np.array([x.ids for x in enc],dtype=np.int64);masks=np.array([x.attention_mask for x in enc],dtype=np.int64)
 inp=temp/'sdcnl_inputs.npz'
 if inp.exists():
  with np.load(inp,allow_pickle=False) as old:assert np.array_equal(old['input_ids'],ids) and np.array_equal(old['attention_mask'],masks)
 else:np.savez_compressed(inp,input_ids=ids,attention_mask=masks)
 for r,n in zip(rows,lengths):r.update(token_length_before_truncation=n,truncated=n>128);r.pop('text')
 # Required primary pair plus every complete jointly accepted CE/SAQS pair actually mounted.
 expected={v for job in external['jobs'].values() for k,v in job['files'].items() if k.endswith('.onnx')};found={}
 paths=sorted(Path(config['input_root']).rglob('*.onnx'));print('Hashing',len(paths),'mounted graphs',flush=True)
 for i,path in enumerate(paths):
  value=sha(path)
  if value in expected:found.setdefault(value,path)
  if (i+1)%10==0:print('Hashed',i+1,flush=True)
 def model(arm,seednum,variant,tau):
  original=external['jobs'].get(f'{arm}__{seednum}__{variant}')
  if not original:return None
  values=[v for k,v in original['files'].items() if k.endswith('.onnx')];assert len(values)==1;value=values[0]
  if value not in found:return None
  return dict(id=f'{arm}__{seednum}__{variant}',arm=arm,seed=seednum,variant=variant,tau=tau,path=str(found[value]),sha256=value)
 models={};coverage=[]
 for variant in ['fp32','q_quint8']:
  m=model('saqs',42,variant,external['primary']['tau'])
  if m is None:raise RuntimeError('Attach the same WHOLE original model-containing Kaggle output. Missing primary '+variant)
  models[m['id']]=m
 for s in [42,123,777,1,2,3,4,5,6,7]:
  selected=[selection['models'].get(f'{a}__{s}',{}).get('selected') for a in ['ce','saqs']]
  wanted=[]
  if all(selected):
   for arm,sel in zip(['ce','saqs'],selected):
    for variant in ['fp32',sel['variant']]:wanted.append(model(arm,s,variant,sel['tau']))
  include=bool(wanted) and all(wanted)
  if include:
   for m in wanted:
    if m['id'] in models:assert models[m['id']]['tau']==m['tau'],'Conflicting frozen thresholds'
    models.setdefault(m['id'],m)
  coverage.append(dict(seed=s,included=include,reason='complete jointly accepted pair available' if include else 'not jointly accepted or incomplete mounted artifacts'))
 code=root/'source_code';code.mkdir(exist_ok=True)
 for f in HERE.glob('*.py'):(code/f.name).write_bytes(f.read_bytes())
 plan=dict(version='crisisq_sdcnl_frozen_v1',configuration=config,source=source,models=list(models.values()),coverage=coverage,selection_hash=digest(selection),rules_sha256=sha(HERE/'frozen_rules.json'),tokenizer_sha256=hashlib.sha256(tokenizer_bytes).hexdigest(),max_length=128,input_recipe='raw title + two newlines + raw selftext; never author/url/cleaned fields; frozen gate on full input, neural truncated to128',runtime='1.31.1',optimization='ORT_ENABLE_ALL',threads=4,case_metadata_hash=digest(rows),overlap_coverage_sha256=sha(root/'overlap_coverage.json'),inputs_sha256=sha(inp),implementation={f.name:sha(f) for f in HERE.glob('*.py')},system=dict(platform=platform.platform(),python=sys.version,machine=platform.machine(),cpu_count=os.cpu_count()),primary_analysis='authors test split, exact-deduplicated, conflict/known-overlap/empty-removed exclusions; source-label agreement only',secondary_analysis='all source rows under same exclusions and raw authors test/all sensitivity; authors training split is source metadata, never used to train CrisisQ here',historical_training_overlap='incompletely auditable; no guaranteed independence',source_labels='is_suicide:1=r/SuicideWatch,0=r/Depression; not adjudicated crisis labels')
 h=digest(plan);pf=root/'protocol_frozen.json'
 if pf.exists():assert json.loads(pf.read_text())['plan_hash']==h,'Inputs, code or host changed. Use new output and temporary folders.'
 else:atomic(pf,dict(plan_hash=h,protocol=plan))
 atomic(root/'case_metadata.json',rows);jobs=[]
 for m in models.values():jobs.append(dict(id=m['id'],model_id=m['id'],model_path=m['path'],model_sha256=m['sha256'],tau=m['tau'],indices=list(range(len(rows))),inputs_path=str(inp),inputs_sha256=sha(inp),plan_hash=h,output=str(root/'jobs'/m['id']),require_isolated=True,worker_sha256=sha(HERE/'worker.py'),runtime='1.31.1',optimization='ORT_ENABLE_ALL',threads=4))
 atomic(root/'jobs_frozen.json',jobs);print('FROZEN:',h,'cases',len(rows),'models',len(models),'clean test',sum(r['clean_eligible'] and r['authors_test'] for r in rows),flush=True)
 return jobs

def install(config):
 root=Path(config['output_root']);python=environment.ensure_environment(Path(config['temporary_root'])/'runtime_1.31.1')
 probe=subprocess.run([str(python),'-I','-c','import onnxruntime,numpy;assert onnxruntime.__version__=="1.31.1" and numpy.__version__=="2.1.3"'],capture_output=True,text=True)
 if probe.returncode:
  with (root/'runtime_install.log').open('w') as f:status=subprocess.run(environment.pip_command(python,'install','--only-binary=:all:','onnxruntime==1.31.1','numpy==2.1.3'),stdout=f,stderr=subprocess.STDOUT)
  if status.returncode:raise RuntimeError((root/'runtime_install.log').read_text()[-3000:])
 info=json.loads(subprocess.check_output([str(python),'-I','-c','import json,onnxruntime as o,numpy,sys;print(json.dumps(dict(runtime=o.__version__,numpy=numpy.__version__,build=o.get_build_info(),module=o.__file__,python=sys.version)))'],text=True))
 native=Path(info['module']).parent;info['native_hashes']={str(p.relative_to(native)):sha(p) for p in sorted(native.rglob('*.so'))};f=root/'runtime_environment.json'
 if f.exists():assert json.loads(f.read_text())==info,'Runtime build changed'
 else:atomic(f,info)
 (root/'installed_packages.txt').write_text(subprocess.check_output(environment.pip_command(python,'freeze','--all'),text=True));return python

def execute(config,python):
 root=Path(config['output_root']);jobs=json.loads((root/'jobs_frozen.json').read_text());failures=[]
 for i,j in enumerate(jobs,1):
  d=Path(j['output']);d.mkdir(parents=True,exist_ok=True);done=d/'complete.json'
  if done.exists():
   c=json.loads(done.read_text());assert c['job_identity']==digest(j) and c['prediction_sha256']==sha(d/'predictions.npz');print('Cached',i,j['id'],flush=True);continue
  atomic(d/'job.json',j);print('Running',i,'/',len(jobs),j['id'],flush=True)
  with (d/'worker.log').open('a') as log:
   process=subprocess.Popen([str(python),'-I',str(HERE/'worker.py'),str(d/'job.json')],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'});start=time.time();last=start
   while process.poll() is None:
    if time.time()-start>5400:process.kill();process.wait();break
    if time.time()-last>=30:print((d/'worker.log').read_text()[-180:],flush=True);last=time.time()
    time.sleep(1)
  if process.returncode or not done.exists():failures.append(j['id']);print((d/'worker.log').read_text()[-1500:],flush=True)
  atomic(root/'execution_progress.json',dict(planned=len(jobs),completed=sum((Path(k['output'])/'complete.json').exists() for k in jobs),failures=failures))
 if failures:raise RuntimeError('Failed jobs retained; rerun on unchanged host to resume: '+str(failures))
if __name__=='__main__':prepare(json.loads(Path(sys.argv[1]).read_text()))
