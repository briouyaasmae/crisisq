from pathlib import Path
import csv,json,hashlib,zipfile
import numpy as np

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def csvwrite(path,rows):
 if not rows:return
 with Path(path).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def pack(root):
 root=Path(root);out=root.parent/(root.name+'_reports.zip')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file() and p.suffix not in ['.onnx','.partial'] and p.name!='checkpoint.npz':z.write(p,str(p.relative_to(root)))
 return out

def main(root):
 root=Path(root);frozen=json.loads((root/'protocol_frozen.json').read_text());plan=frozen['protocol'];cases=json.loads((root/'case_metadata.json').read_text());jobs=json.loads((root/'jobs_frozen.json').read_text());n=len(cases)
 assert digest(plan)==frozen['plan_hash'] and digest(cases)==plan['case_metadata_hash'],'Frozen plan/case metadata changed'
 y=np.array([r['label'] for r in cases]);gate=np.array([r['gate_v2'] for r in cases]);clean=np.array([r['clean_eligible'] for r in cases]);test=np.array([r['authors_test'] for r in cases]);preds={};probs={}
 panels={'authors_test_clean_primary':test&clean,'all_posts_clean_secondary':clean,'authors_test_raw_sensitivity':test,'all_posts_raw_sensitivity':np.ones(n,dtype=bool)}
 # Freeze author-cluster resamples independent of predictions, same resamples within panel/contrast.
 samplers={}
 for name,m in panels.items():
  ix=np.flatnonzero(m);authors=[cases[i]['author_group'] for i in ix];unique=sorted(set(authors));lookup={x:i for i,x in enumerate(unique)};group=np.array([lookup[a] for a in authors],dtype=int)
  rng=np.random.default_rng(20261114);sample=rng.integers(0,len(unique),size=(1000,len(unique))) if unique else np.empty((0,0),dtype=int)
  samplers[name]=(ix,group,sample,len(unique))
 def ratio_ci(name,numerator,denominator):
  ix,g,s,k=samplers[name]
  if not len(ix):return ('','','')
  num=np.bincount(g,weights=np.asarray(numerator)[ix],minlength=k);den=np.bincount(g,weights=np.asarray(denominator)[ix],minlength=k)
  if den.sum()==0:return ('','','')
  a=num[s].sum(1);b=den[s].sum(1);valid=b>0;values=a[valid]/b[valid]
  return float(num.sum()/den.sum()),float(np.quantile(values,.025)),float(np.quantile(values,.975))
 metrics=[];rowsout=[];changes=[];comparisons=[]
 for j in jobs:
  d=Path(j['output']);c=json.loads((d/'complete.json').read_text());assert c['complete'] and c['plan_hash']==frozen['plan_hash'] and c['job_identity']==digest(j) and c['prediction_sha256']==sha(d/'predictions.npz')
  assert c['repeat_decision_changes']==0,'Within-session repeat instability: investigate'
  with np.load(d/'predictions.npz',allow_pickle=False) as a:
   assert list(a['indices'])==list(range(n));p=a['probabilities'].copy();assert np.isfinite(p).all()
  probs[j['model_id']]=p;neural=p>=j['tau'];hybrid=np.where(gate==-1,neural,gate==1)
  for mode,pred in [('neural',neural),('hybrid',hybrid)]:
   preds[(j['model_id'],mode)]=pred
   for panel,m in panels.items():
    recall=ratio_ci(panel,pred*(y==1),y==1);alerts=ratio_ci(panel,pred*(y==0),y==0);agreement=ratio_ci(panel,pred==y,np.ones(n));overall=ratio_ci(panel,pred,np.ones(n))
    pos=m&(y==1);neg=m&(y==0);tp=int(sum(pos&pred));fn=int(sum(pos&~pred));tn=int(sum(neg&~pred));fp=int(sum(neg&pred));precision=tp/(tp+fp) if tp+fp else '';f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else ''
    metrics.append(dict(model=j['model_id'],mode=mode,panel=panel,tau=j['tau'],n=int(sum(m)),author_clusters=samplers[panel][3],source_positive=int(sum(pos)),source_negative=int(sum(neg)),detected_source_positive=tp,missed_source_positive=fn,alerts_on_source_negative=fp,nonalerts_on_source_negative=tn,source_positive_recall=recall[0],recall_ci_low=recall[1],recall_ci_high=recall[2],source_negative_alert_rate=alerts[0],negative_alert_ci_low=alerts[1],negative_alert_ci_high=alerts[2],source_label_agreement=agreement[0],agreement_ci_low=agreement[1],agreement_ci_high=agreement[2],overall_alert_rate=overall[0],precision_against_source_labels=precision,f1_against_source_labels=f1,ci_method='1000 author-cluster percentile bootstrap; within-model sampling only; not seed uncertainty'))
  for i,r in enumerate(cases):rowsout.append(dict(model=j['model_id'],source_id=r['source_id'],text_hash=r['text_hash'],source_label=r['label'],authors_test=r['authors_test'],clean_eligible=r['clean_eligible'],gate_v2=r['gate_v2'],truncated=r['truncated'],tau=j['tau'],probability=float(p[i]),neural_decision=int(neural[i]),hybrid_decision=int(hybrid[i])))
 def compare(a,b,description):
  pa=preds[a];pb=preds[b]
  for panel,m in panels.items():
   recall=ratio_ci(panel,(pb.astype(int)-pa.astype(int))*(y==1),y==1);alerts=ratio_ci(panel,(pb.astype(int)-pa.astype(int))*(y==0),y==0)
   comparisons.append(dict(contrast=description,baseline=a[0]+'|'+a[1],comparison=b[0]+'|'+b[1],panel=panel,n=int(sum(m)),changed_decisions=int(sum(m&(pa!=pb))),source_positives_lost=int(sum(m&(y==1)&pa&~pb)),source_positives_gained=int(sum(m&(y==1)&~pa&pb)),source_negative_alerts_added=int(sum(m&(y==0)&~pa&pb)),source_negative_alerts_removed=int(sum(m&(y==0)&pa&~pb)),delta_source_positive_recall=recall[0],delta_recall_ci_low=recall[1],delta_recall_ci_high=recall[2],delta_source_negative_alert_rate=alerts[0],delta_alert_ci_low=alerts[1],delta_alert_ci_high=alerts[2]))
  for i in np.flatnonzero(pa!=pb):changes.append(dict(contrast=description,source_id=cases[i]['source_id'],text_hash=cases[i]['text_hash'],source_label=int(y[i]),authors_test=bool(test[i]),clean_eligible=bool(clean[i]),gate_v2=int(gate[i]),baseline_decision=int(pa[i]),comparison_decision=int(pb[i])))
 for j in jobs:
  mid=j['model_id'];compare((mid,'neural'),(mid,'hybrid'),'routing:'+mid)
  fp=f"{j.get('arm',mid.split('__')[0])}__{mid.split('__')[1]}__fp32"
  if not mid.endswith('__fp32') and fp in probs:
   for mode in ['neural','hybrid']:compare((fp,mode),(mid,mode),'quantization:'+mid+':'+mode)
 # Arm comparisons are conditional on both seeds passing historical development selection.
 seedrows=[]
 models=plan['models']
 for cov in plan['coverage']:
  if not cov['included']:continue
  s=cov['seed']
  for kind in ['fp32','source_selected_quantized']:
   pair=[]
   for arm in ['ce','saqs']:
    candidates=[m for m in models if m['arm']==arm and m['seed']==s and ((m['variant']=='fp32') if kind=='fp32' else (m['variant']!='fp32'))];assert len(candidates)==1;pair.append(candidates[0]['id'])
   for mode in ['neural','hybrid']:
    compare((pair[0],mode),(pair[1],mode),f'SAQS-minus-CE:seed{s}:{kind}:{mode}')
    for panel,m in panels.items():
     ce=preds[(pair[0],mode)];saqs=preds[(pair[1],mode)];pos=m&(y==1);neg=m&(y==0)
     seedrows.append(dict(seed=s,kind=kind,mode=mode,panel=panel,delta_recall=float(np.mean(saqs[pos])-np.mean(ce[pos])) if sum(pos) else '',delta_source_negative_alert_rate=float(np.mean(saqs[neg])-np.mean(ce[neg])) if sum(neg) else ''))
 intervals=[]
 for kind in ['fp32','source_selected_quantized']:
  for mode in ['neural','hybrid']:
   for panel in panels:
    selected=[r for r in seedrows if r['kind']==kind and r['mode']==mode and r['panel']==panel]
    for metric in ['delta_recall','delta_source_negative_alert_rate']:
     a=np.array([r[metric] for r in selected if r[metric]!=''])
     if not len(a):continue
     rng=np.random.default_rng(20261114);boot=a[rng.integers(0,len(a),size=(10000,len(a)))].mean(1)
     intervals.append(dict(kind=kind,mode=mode,panel=panel,metric=metric,jointly_accepted_available_seed_pairs=len(a),mean_delta=float(a.mean()),ci_low=float(np.quantile(boot,.025)) if len(a)>1 else '',ci_high=float(np.quantile(boot,.975)) if len(a)>1 else '',method='paired seed percentile bootstrap, conditional on joint development acceptance; descriptive selected-seed uncertainty'))
 csvwrite(root/'metrics.csv',metrics);csvwrite(root/'predictions_text_free.csv',rowsout);csvwrite(root/'paired_decision_effects.csv',comparisons);csvwrite(root/'changed_decisions.csv',changes);csvwrite(root/'ce_saqs_per_seed.csv',seedrows);csvwrite(root/'ce_saqs_paired_seed_intervals.csv',intervals)
 summary=dict(source_rows=n,authors_test_rows=int(sum(test)),clean_primary_test=int(sum(test&clean)),clean_all=int(sum(clean)),known_exact_overlap_rows=sum(r['known_exact_overlap'] for r in cases),duplicate_nonrepresentatives=sum(not r['duplicate_representative'] for r in cases),conflicting_label_rows=sum(r['label_conflict'] for r in cases),empty_removed_rows=sum(r['empty_or_removed'] for r in cases),truncated_rows=sum(r['truncated'] for r in cases),truncated_test_rows=sum(r['truncated'] and r['authors_test'] for r in cases),gate_crisis=sum(gate==1).item(),gate_safe=sum(gate==0).item(),gate_neural=sum(gate==-1).item(),counts_note='Exclusion categories can overlap; do not add them',historical_training_overlap='Not certified. Exact detectable overlap only; no near-duplicate exclusion or complete original-training audit.')
 (root/'dataset_summary.json').write_text(json.dumps(summary,indent=2));text='''SDCNL evaluation complete. Primary panel: authors_test_clean_primary.\nRead metrics.csv, paired_decision_effects.csv, dataset_summary.json and overlap_coverage.json.\nLabels denote SuicideWatch/depression subreddit membership. Recall/precision/F1 are against those source labels. Alerts on depression posts are not adjudicated false positives.\nAll-post and raw panels are sensitivity analyses sharing messages, not independent confirmations. Original SDCNL train/test labels were never used to train or select CrisisQ in this notebook.\nKnown overlap exclusions do not prove training independence: unavailable original training membership and near duplicates remain unresolved.\nGate sees the full title/body, neural model sees first128 tokens. Token lengths and truncation are reported. Frozen behavior is not altered for this dataset.\nPost-level metrics have author-cluster percentile intervals. CE/SAQS intervals resample jointly accepted available seed pairs; selection can bias the arm comparison. No seed pooling as independent messages.\nRuntime is fixed at ORT1.31.1/ALL/4 CPU threads. Results are specific to that environment and are not phone measurements.\nNo retraining, threshold search, new annotation or clinical validation. Reports exclude original posts, titles, author strings and URLs.\n'''
 (root/'READ_ME_results.txt').write_text(text)
 failure=root/'failure.json'
 if failure.exists():failure.unlink()
 result=dict(all_jobs_complete=True,models=len(jobs),rows=n,plan_hash=frozen['plan_hash']);(root/'completion.json').write_text(json.dumps(result,indent=2));pack(root);return result
