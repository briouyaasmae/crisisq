from pathlib import Path
import base64,collections,csv,gzip,io,json,platform,sys,urllib.request
import numpy as np
from common import sha,digest,atomic,freeze,gates
HERE=Path(__file__).resolve().parent

def fetch(record,path):
 path=Path(path)
 if not path.exists():
  with urllib.request.urlopen(urllib.request.Request(record['url'],headers={'User-Agent':'CrisisQ-selective-precision-study'}),timeout=120) as r:data=r.read()
  assert __import__('hashlib').sha256(data).hexdigest()==record['sha256'],'Pinned dataset bytes differ'
  path.write_bytes(data)
 assert sha(path)==record['sha256'];return path.read_bytes()
def main(config):
 from tokenizers import Tokenizer
 import tokenizers
 assert tokenizers.__version__=='0.23.3'
 root=Path(config['output_root']);temp=Path(config['temporary_root']);root.mkdir(parents=True,exist_ok=True);temp.mkdir(parents=True,exist_ok=True)
 seed=json.loads(gzip.decompress((HERE/'full_evaluation_seed.json.gz').read_bytes()));external=json.loads((HERE/'external_frozen.json').read_text());selection=json.loads((HERE/'selection_frozen.json').read_text());rules=json.loads((HERE/'frozen_rules.json').read_text());gate=gates(rules)
 assert digest(external)==seed['external_plan_hash'] and digest(selection)==external['source_selection_hash']
 # Prefer the exact original packet if present; otherwise reconstruct pinned public data.
 wanted='a24de8c2b432ddbe3880a579abc9106cde59d38b9f545eeae30f73ad955b1372'
 packet=next((p for p in sorted(Path(config['input_root']).rglob('full_evaluation_cases.jsonl')) if sha(p)==wanted),None)
 if packet is None:
  import build_full_device_packet
  build_full_device_packet.main(seed,temp/'twitter_packet');packet=temp/'twitter_packet/full_evaluation_cases.jsonl'
 assert sha(packet)==wanted
 twitter=[json.loads(line) for line in packet.read_text().splitlines()];assert len(twitter)==1700
 sizes={('binary_test',1):64,('binary_test',0):64,('positive_probe',1):64,('positive_probe',0):32,('labeled_hard_negative',0):32};cal=[]
 for (part,label),count in sizes.items():
  pool=[i for i,r in enumerate(twitter) if r['partition']==part and r['label']==label]
  pool.sort(key=lambda i:__import__('hashlib').sha256(('CrisisQ-runtime-panel-v1|'+twitter[i]['source_id']).encode()).hexdigest());cal+=pool[:count]
 cal=sorted(cal);assert len(set(cal))==256
 known={r['text_hash'] for r in twitter};rows=[];texts=[];ids=[];masks=[]
 for i,r in enumerate(twitter):
  g,_=gate(r['text']);assert (-1 if g is None else g)==r['gate_v2']
  rows.append(dict(source_id=r['source_id'],text_hash=r['text_hash'],label=r['label'],group_id=r['group_id'],partition=r['partition'],gate_v2=r['gate_v2'],calibration=i in cal));texts.append(r['text']);ids.append(r['input_ids']);masks.append(r['attention_mask'])
 source=json.loads((HERE/'source_manifest.json').read_text());record=source['files']['testing-set.csv'];raw=fetch(record,temp/'testing-set.csv');test=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));assert len(test)==379
 tokbytes=base64.b64decode(seed['tokenizer_base64']);assert __import__('hashlib').sha256(tokbytes).hexdigest()==seed['model_hashes']['tokenizer.json'];(temp/'tokenizer.json').write_bytes(tokbytes)
 tok=Tokenizer.from_str(tokbytes.decode());tok.enable_truncation(max_length=128);tok.enable_padding(length=128,pad_id=0,pad_token='[PAD]')
 from build_full_device_packet import normal
 staged=[];excluded=[]
 for i,r in enumerate(test):
  text=r['title'].strip()+'\n\n'+r['selftext'].strip();h=__import__('hashlib').sha256(normal(text).encode()).hexdigest();body=__import__('hashlib').sha256(normal(r['selftext']).encode()).hexdigest();label=int(r['is_suicide']);assert label in [0,1]
  staged.append((i,r,text,h,body,label))
 counts=collections.Counter(x[3] for x in staged);labels=collections.defaultdict(set)
 for x in staged:labels[x[3]].add(x[5])
 seen=set()
 for i,r,text,h,body,label in staged:
  reason='known_twitter_overlap' if h in known or body in known else 'empty_or_removed' if normal(r['selftext']) in ['','removed','deleted'] else 'conflicting_labels' if len(labels[h])>1 else 'duplicate' if h in seen else None
  seen.add(h)
  if reason:excluded.append(dict(source_id='sdcnl:test:'+str(i),text_hash=h,reason=reason));continue
  g,_=gate(text);enc=tok.encode(text);author=r.get('author','').strip().casefold();group=digest(['sdcnl_author',author]) if author not in ['','[deleted]'] else h
  rows.append(dict(source_id='sdcnl:test:'+str(i),text_hash=h,label=label,group_id=group,partition='sdcnl_authors_test',gate_v2=-1 if g is None else g,calibration=False));texts.append(text);ids.append(enc.ids);masks.append(enc.attention_mask)
 ids=np.array(ids,dtype=np.int64);masks=np.array(masks,dtype=np.int64);inp=temp/'inputs.npz'
 if inp.exists():
  with np.load(inp,allow_pickle=False) as old:assert np.array_equal(old['input_ids'],ids) and np.array_equal(old['attention_mask'],masks)
 else:np.savez_compressed(inp,input_ids=ids,attention_mask=masks)
 (temp/'texts.json').write_text(json.dumps(texts));assert all(len(v)==128 for v in ids)
 # Fixed extension list, not the best observed checkpoints. Primary pair is mandatory.
 requests=[('saqs',42),('saqs',123),('saqs',777),('ce',42)] if config['model_scope']=='fixed_extensions' else [('saqs',42)]
 wanted_models={}
 for arm,s in requests:
  sel=selection['models'][f'{arm}__{s}']['selected'];assert sel
  for variant in ['fp32',sel['variant']]:
   job=external['jobs'][f'{arm}__{s}__{variant}'];values=[v for k,v in job['files'].items() if k.endswith('.onnx')];assert len(values)==1;wanted_models[(arm,s,variant)]=(values[0],sel['tau'])
 found={}
 for path in sorted(Path(config['input_root']).rglob('*.onnx')):
  h=sha(path)
  if h in {v[0] for v in wanted_models.values()}:found.setdefault(h,str(path))
  if len(found)==len({v[0] for v in wanted_models.values()}):break
 models=[];coverage=[]
 for arm,s in requests:
  sel=selection['models'][f'{arm}__{s}']['selected'];present=all(wanted_models[(arm,s,v)][0] in found for v in ['fp32',sel['variant']])
  coverage.append(dict(arm=arm,seed=s,included=present))
  if not present:
   if (arm,s)==('saqs',42):raise FileNotFoundError('Missing exact primary FP32/QUInt8 graphs. Attach the same WHOLE original nonclinical model-containing notebook output under /kaggle/input; no ZIP required.')
   continue
  pair=dict(id=f'{arm}__{s}',arm=arm,seed=s,tau=sel['tau'],compressed_variant=sel['variant'])
  for label,variant in [('fp32','fp32'),('compressed',sel['variant'])]:
   h,_=wanted_models[(arm,s,variant)];pair[label]=dict(path=found[h],sha256=h)
  models.append(pair)
 implementation={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file()}
 protocol=dict(version='crisisq_selective_precision_v1',configuration=config,models=models,coverage=coverage,calibration_indices=cal,calibration_scope='the previously used label-stratified 256-message runtime panel; only compressed scores/gates determine fallback widths',evaluation_scope='remaining Twitter rows plus eligible SDCNL authors test; all source corpora previously inspected, not a new untouched test',labels='source-derived; no clinical interpretation',historical_overlap='incomplete historical training coverage; exact Twitter overlap excluded for SDCNL, no near-duplicate claim',inputs_sha256=sha(inp),case_metadata_hash=digest(rows),texts_sha256=sha(temp/'texts.json'),tokenizer_sha256=sha(temp/'tokenizer.json'),rules_sha256=sha(HERE/'frozen_rules.json'),sdcnl_source=record,primary_policy='one_sided_05',sensitivity_budgets=[.01,.10,.20],control='symmetric_05 and deterministic random same-count fallback on QUInt8-negative routed cases',calibration_runtime='1.31.1',runtime_versions=config['runtime_versions'],classification_thresholds='unchanged per checkpoint; fallback widths are new label-free routing parameters, not fitted classification thresholds',implementation=implementation,host=dict(platform=platform.platform(),machine=platform.machine(),cpu_count=__import__('os').cpu_count(),python=sys.version))
 cpu=Path('/proc/cpuinfo')
 if cpu.exists():protocol['host']['cpu_summary']=[l for l in cpu.read_text().splitlines() if l.startswith(('model name','flags','Hardware','CPU architecture'))][:4]
 h=freeze(root/'protocol_frozen.json',protocol);atomic(root/'case_metadata.json',rows);atomic(root/'source_exclusions.json',excluded);jobs=[]
 for pair in models:
  for version in config['runtime_versions']:
   for kind in ['fp32','compressed']:
    job=dict(id=pair['id']+'__'+kind+'__'+version,model_id=pair['id']+'__'+kind,model_path=pair[kind]['path'],model_sha256=pair[kind]['sha256'],tau=pair['tau'],indices=list(range(len(rows))),inputs_path=str(inp),inputs_sha256=sha(inp),plan_hash=h,require_isolated=True,worker_sha256=sha(HERE/'inference_worker.py'),runtime=version,optimization='ORT_ENABLE_ALL',threads=4)
    job['output']=str(root/'scores'/job['id']);jobs.append(job)
 freeze(root/'score_jobs.json',jobs);print('Frozen',len(models),'checkpoint pairs,',len(rows),'messages,',len(jobs),'score jobs.',flush=True)
 return protocol
