import os
os.environ["MPLBACKEND"] = "Agg"  # Set BEFORE any Matplotlib import, including installation probes.
from pathlib import Path
import gzip,hashlib,json
import numpy as np
from common import *
HERE=Path(__file__).resolve().parent

def load(root,pair,kind,version):
 path=root/'scores'/f"{pair['id']}__{kind}__{version}"
 record=json.loads((path/'complete.json').read_text());p=path/'predictions.npz'
 assert record['complete'] and sha(p)==record['prediction_sha256']
 assert record['model_sha256']==pair[kind]['sha256']
 with np.load(p,allow_pickle=False) as z:
  assert np.array_equal(z['indices'],np.arange(record['n']))
  return z['probabilities'].copy()
def main(root):
 root=Path(root);plan=json.loads((root/'protocol_frozen.json').read_text());assert sha(__file__)==plan['implementation']['analyze.py'],'Analysis implementation changed';rows=json.loads((root/'case_metadata.json').read_text());assert digest(rows)==plan['case_metadata_hash'];g=np.array([r['gate_v2'] for r in rows]);y=np.array([r['label'] for r in rows]);cal=plan['calibration_indices'];groups=[r['group_id'] for r in rows]
 panel={part:np.array([i for i,r in enumerate(rows) if r['partition']==part and not r['calibration']],int) for part in sorted({r['partition'] for r in rows})}
 assert all(not rows[i]['calibration'] for ix in panel.values() for i in ix)
 panels={k:v for k,v in panel.items() if len(v)};bands={};scores={}
 for pair in plan['models']:
  q=load(root,pair,'compressed','1.31.1');bands[pair['id']]={}
  for name,side,budget in [('one_sided_01','one_sided',.01),('one_sided_05','one_sided',.05),('one_sided_10','one_sided',.10),('one_sided_20','one_sided',.20),('symmetric_05','symmetric',.05)]:
   width=fit_width(q,g,cal,pair['tau'],budget,side);route=mask(q,g,pair['tau'],side,width)
   bands[pair['id']][name]=dict(side=side,budget=budget,width=width,calibration_fallbacks=int(route[cal].sum()),calibration_neural_routes=int((g[cal]<0).sum()))
 freeze(root/'routing_parameters_frozen.json',dict(calibration_runtime='1.31.1',calibration_indices_sha256=digest(cal),calibration_labels_used=False,classification_thresholds_changed=False,parameters=bands))
 metrics=[];intervals=[];random=[];drift=[];changes=[];baseline_checks=[];policy_decisions={}
 for pair in plan['models']:
  tau=pair['tau']
  for version in plan['runtime_versions']:
   q=load(root,pair,'compressed',version);f=load(root,pair,'fp32',version);assert len(q)==len(rows)==len(f)
   qd=decision(q,g,tau);fd=decision(f,g,tau);scores[(pair['id'],version)]=(q,f)
   decisions={'always_compressed':qd,'always_fp32':fd};routes={'always_compressed':np.zeros(len(g),bool),'always_fp32':g<0}
   for name,b in bands[pair['id']].items():
    use=mask(q,g,tau,b['side'],b['width']);decisions[name]=routed_prediction(q,f,g,tau,use);routes[name]=use
    if b['side']=='one_sided':assert not ((qd==1)&(decisions[name]==0)).any(), 'One-sided preservation invariant failed'
   for name,pred in decisions.items():
    policy_decisions[(pair['id'],version,name)]=pred
    if name not in ['always_compressed','always_fp32']:
     for i,r in enumerate(rows):
      if not r['calibration'] and (routes[name][i] or pred[i]!=qd[i]):changes.append(dict(model=pair['id'],runtime=version,policy=name,source_id=r['source_id'],text_hash=r['text_hash'],partition=r['partition'],source_label=r['label'],gate=int(g[i]),compressed_probability=float(q[i]),fp32_probability=float(f[i]),fallback=bool(routes[name][i]),compressed_decision=int(qd[i]),fp32_decision=int(fd[i]),policy_decision=int(pred[i])))
   if pair['id']=='saqs__42' and version=='1.31.1':
    historical=json.loads(gzip.decompress((HERE/'full_evaluation_seed.json.gz').read_bytes()));reference={r['source_id']:r['reference'] for r in historical['labeled_rows']}
    ix=[i for i,r in enumerate(rows) if r['source_id'] in reference]
    for label,pp,key in [('fp32',f,'fp32'),('compressed',q,'q_quint8')]:
     old=np.array([reference[rows[i]['source_id']][key]['probability'] for i in ix]);new=pp[ix];delta=np.abs(new-old)
     baseline_checks.append(dict(model=pair['id'],runtime=version,precision=label,n=len(ix),max_probability_difference=float(delta.max()),tolerance_failures=int((delta>1e-5+1e-5*np.abs(old)).sum()),neural_decision_differences=int(((new>=tau)!=(old>=tau)).sum()),scope='current host versus historical Kaggle references; disagreement is recorded, not silently repaired'))
   for part,ix in panels.items():
    eligible=ix[(g[ix]<0)&(q[ix]<tau)];k=int(routes['one_sided_05'][ix].sum());assert k<=len(eligible)
    ordered=sorted(eligible,key=lambda i:hashlib.sha256(('CrisisQ-fallback-random-v1|'+rows[i]['source_id']).encode()).hexdigest());r_mask=np.zeros(len(g),bool);r_mask[ordered[:k]]=True
    r_pred=routed_prediction(q,f,g,tau,r_mask)
    for name,pred in list(decisions.items())+[('random_one_sided_05_matched',r_pred)]:
     use=r_mask if name=='random_one_sided_05_matched' else routes[name]
     item=dict(model=pair['id'],compressed_variant=pair['compressed_variant'],runtime=version,partition=part,policy=name,fallback_calls=int(use[ix].sum()) if name!='always_fp32' else 0,fp32_calls=int(use[ix].sum()),compressed_calls=0 if name=='always_fp32' else int((g[ix]<0).sum()),neural_route_count=int((g[ix]<0).sum()),fallback_fraction_all_messages=float(use[ix].mean()) if name!='always_fp32' else 0.,**metric(y[ix],pred[ix],fd[ix],qd[ix]))
     metrics.append(item)
     if name in ['one_sided_05','symmetric_05','random_one_sided_05_matched']:
      for positive,label in [(True,'recall'),(False,'source_negative_alert_rate')]:
       lo,hi=group_delta(y[ix],qd[ix],pred[ix],np.array(groups)[ix],positive)
       valid=(y[ix]==(1 if positive else 0));delta=float((pred[ix][valid]-qd[ix][valid]).mean()) if valid.any() else None
       intervals.append(dict(model=pair['id'],runtime=version,partition=part,policy=name,metric=label,delta_vs_compressed=delta,cluster_lo=lo,cluster_hi=hi,scope='paired source-group/author bootstrap;1000; fixed model; previously inspected source rows'))
    losses=int(((y[eligible]==1)&(fd[eligible]==1)).sum());added=int(((y[eligible]==0)&(fd[eligible]==1)).sum());E=len(eligible)
    sim=np.random.default_rng(20261115).hypergeometric(losses,E-losses,k,size=10000) if E and k else np.zeros(10000)
    actual=int(((y[ix]==1)&(fd[ix]==1)&(qd[ix]==0)&(decisions['one_sided_05'][ix]==1)).sum())
    random.append(dict(model=pair['id'],runtime=version,partition=part,eligible_negative_routes=E,matched_fallbacks=k,baseline_positive_losses=losses,one_sided_05_recovered=actual,random_expected_recovered=k*losses/E if E else 0.,random_recovery_reference_lo=float(np.quantile(sim,.025)),random_recovery_reference_hi=float(np.quantile(sim,.975)),random_expected_added_negative_alerts=k*added/E if E else 0.,reference_interval='randomization distribution, not population confidence interval'))
  if len(plan['runtime_versions'])==2:
   a,b=plan['runtime_versions']
   for name in decisions:
    p=policy_decisions[(pair['id'],a,name)];q=policy_decisions[(pair['id'],b,name)]
    for part,ix in panels.items():drift.append(dict(model=pair['id'],partition=part,policy=name,n=len(ix),runtime_a=a,runtime_b=b,decision_disagreements=int((p[ix]!=q[ix]).sum())))
 write_csv(root/'policy_case_changes.csv',changes);write_csv(root/'historical_baseline_checks.csv',baseline_checks)
 write_csv(root/'metrics.csv',metrics);write_csv(root/'paired_group_intervals.csv',intervals);write_csv(root/'matched_random_reference.csv',random);write_csv(root/'cross_runtime_decisions.csv',drift)
 # Timing indices are fixed by source IDs, not scores/labels; independent of route budget.
 primary=next(p for p in plan['models'] if p['id']=='saqs__42');q,f=scores[(primary['id'],'1.31.1')];bench=[]
 for part in ['binary_test','sdcnl_authors_test']:
  pool=panels.get(part,np.array([],int));pool=sorted(pool,key=lambda i:hashlib.sha256(('CrisisQ-fallback-timing-v1|'+rows[i]['source_id']).encode()).hexdigest());bench+=pool[:64]
 bench=sorted(int(i) for i in bench);assert all(not rows[i]['calibration'] for i in bench)
 jobs=[]
 for version in plan['runtime_versions']:
  q,f=scores[(primary['id'],version)]
  for policy in ['always_compressed','always_fp32','one_sided_05','symmetric_05','random_one_sided_05_matched']:
   ids=[]
   for part in ['binary_test','sdcnl_authors_test']:
    ix=np.array([i for i in bench if rows[i]['partition']==part],int);use=mask(q,g,primary['tau'],'one_sided',bands[primary['id']]['one_sided_05']['width']);k=int(use[ix].sum());eligible=[i for i in ix if g[i]<0 and q[i]<primary['tau']];eligible.sort(key=lambda i:hashlib.sha256(('CrisisQ-fallback-random-v1|'+rows[i]['source_id']).encode()).hexdigest());ids+=eligible[:k]
   route=np.zeros(len(g),bool);route[ids]=True
   if policy=='always_compressed':expected=decision(q,g,primary['tau'])
   elif policy=='always_fp32':expected=decision(f,g,primary['tau'])
   else:
    if policy!='random_one_sided_05_matched':b=bands[primary['id']][policy];route=mask(q,g,primary['tau'],b['side'],b['width'])
    expected=routed_prediction(q,f,g,primary['tau'],route)
   jobs.append(dict(runtime=version,policy=policy,indices=bench,random_source_ids=[rows[i]['source_id'] for i in ids],parameters=bands[primary['id']],pair=primary,expected_decisions=[int(expected[i]) for i in bench],protocol_hash=digest(plan),inputs_sha256=plan['inputs_sha256'],worker_sha256=sha(HERE/'benchmark.py')))
 freeze(root/'timing_jobs_frozen.json',jobs)
 # Plot every declared sensitivity point, without selecting a favorable budget.
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
 for part,ax in zip(['binary_test','sdcnl_authors_test'],axes):
  for version in plan['runtime_versions']:
   selected=[r for r in metrics if r['model']=='saqs__42' and r['partition']==part and r['runtime']==version and r['policy'].startswith('one_sided_')];selected.sort(key=lambda r:r['fallback_fraction_all_messages'])
   ax.plot([100*r['fallback_fraction_all_messages'] for r in selected],[r['positive_losses_vs_fp32'] for r in selected],marker='o',label=version)
  ax.set(xlabel='Observed FP32 fallback calls (% messages)',ylabel='Source-positive losses vs FP32',title=part);ax.legend()
 fig.savefig(root/'fallback_tradeoff.png',dpi=180);fig.savefig(root/'fallback_tradeoff.svg');plt.close(fig)
 atomic(root/'analysis_complete.json',dict(complete=True,models=len(plan['models']),n_cases=len(rows),classification_thresholds_changed=False,primary_policy='one_sided_05',benchmark_complete=False,scope=plan['evaluation_scope']))
 print('All declared prediction comparisons written; actual timing is still required.',flush=True)
if __name__=='__main__':
 import sys
 main(sys.argv[1])
