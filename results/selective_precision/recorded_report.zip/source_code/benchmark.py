"""Fresh-process host pipeline timing; no prediction-cache latency estimates."""
from pathlib import Path
import argparse,json,resource,time
import numpy as np
import onnxruntime as ort
from tokenizers import Tokenizer
from common import *
HERE=Path(__file__).resolve().parent

def memory():
 p=Path('/proc/self/smaps_rollup');pss=None
 if p.exists():
  lines=p.read_text().splitlines();pss=next((int(v.split()[1])/1024 for v in lines if v.startswith('Pss:')),None)
 return dict(pss_mib=pss,peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024 if __import__('sys').platform!='darwin' else 1024**2))
def run(jobpath):
 job=json.loads(Path(jobpath).read_text());root=Path(job['output_root']);temp=Path(job['temporary_root']);out=Path(job['destination']);out.mkdir(parents=True,exist_ok=True)
 assert ort.__version__==job['runtime'] and sha(__file__)==job['worker_sha256']
 assert sha(temp/'inputs.npz')==job['inputs_sha256'];plan=json.loads((root/'protocol_frozen.json').read_text());assert digest(plan)==job['protocol_hash']
 assert sha(temp/'texts.json')==plan['texts_sha256'] and sha(temp/'tokenizer.json')==plan['tokenizer_sha256']
 for kind in ['fp32','compressed']:assert sha(job['pair'][kind]['path'])==job['pair'][kind]['sha256']
 rows=json.loads((root/'case_metadata.json').read_text());assert digest(rows)==plan['case_metadata_hash'];texts=json.loads((temp/'texts.json').read_text());gate=gates(json.loads((HERE/'frozen_rules.json').read_text()));tok=Tokenizer.from_file(str(temp/'tokenizer.json'));tok.enable_truncation(max_length=128);tok.enable_padding(length=128,pad_id=0,pad_token='[PAD]')
 with np.load(temp/'inputs.npz',allow_pickle=False) as z:expected_ids=z['input_ids'][job['indices']].copy();expected_masks=z['attention_mask'][job['indices']].copy()
 for k,i in enumerate(job['indices']):
  enc=tok.encode(texts[i]);assert np.array_equal(enc.ids,expected_ids[k]) and np.array_equal(enc.attention_mask,expected_masks[k]),'Benchmark tokenization differs'
 del expected_ids,expected_masks
 options=ort.SessionOptions();options.intra_op_num_threads=4;options.inter_op_num_threads=1;options.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL;options.graph_optimization_level=ort.GraphOptimizationLevel.ORT_ENABLE_ALL;options.add_session_config_entry('session.intra_op.allow_spinning','0')
 start=time.perf_counter();sessions={}
 needed=['compressed'] if job['policy']=='always_compressed' else ['fp32'] if job['policy']=='always_fp32' else ['compressed','fp32']
 for kind in needed:sessions[kind]=ort.InferenceSession(job['pair'][kind]['path'],sess_options=options,providers=['CPUExecutionProvider'])
 init_ms=1000*(time.perf_counter()-start);loaded=memory();tau=job['pair']['tau'];random_ids=set(job['random_source_ids'])
 def probability(session,feed):
  names={x.name for x in session.get_inputs()};assert {'input_ids','attention_mask'}<=names and names<={'input_ids','attention_mask','token_type_ids'}
  if 'token_type_ids' in names:feed={**feed,'token_type_ids':np.zeros_like(feed['input_ids'])}
  logits=np.asarray(session.run(None,feed)[0],float).reshape(-1);assert len(logits)==2 and np.isfinite(logits).all();z=np.exp(logits-logits.max());return float(z[1]/z.sum())
 def pipeline(i):
  g,_=gate(texts[i]);g=-1 if g is None else int(g)
  if g>=0:return g,0,0
  enc=tok.encode(texts[i]);feed={'input_ids':np.array([enc.ids],np.int64),'attention_mask':np.array([enc.attention_mask],np.int64)}
  if job['policy']=='always_fp32':return int(probability(sessions['fp32'],feed)>=tau),0,1
  q=probability(sessions['compressed'],feed)
  if job['policy']=='always_compressed':return int(q>=tau),1,0
  if job['policy']=='random_one_sided_05_matched':use=q<tau and rows[i]['source_id'] in random_ids
  else:
   p=job['parameters'][job['policy']];use=abs(q-tau)<p['width'] and (q<tau if p['side']=='one_sided' else True)
  return int((probability(sessions['fp32'],feed) if use else q)>=tau),1,int(use)
 for i in job['indices'][:10]:pipeline(i)
 warm=memory();records=[];mismatches=0;rng=np.random.default_rng(20261115+job['round'])
 expected=dict(zip(job['indices'],job['expected_decisions']))
 for i in rng.permutation(job['indices']):
  i=int(i);start=time.perf_counter();pred,qcalls,fcalls=pipeline(i);ms=1000*(time.perf_counter()-start);mismatches+=pred!=expected[i]
  records.append(dict(source_id=rows[i]['source_id'],partition=rows[i]['partition'],runtime=job['runtime'],policy=job['policy'],round=job['round'],elapsed_ms=ms,prediction=pred,compressed_calls=qcalls,fp32_calls=fcalls))
 write_csv(out/'timing.csv',records)
 atomic(out/'complete.json',dict(complete=True,job_sha256=sha(jobpath),runtime=ort.__version__,ort_build=ort.get_build_info(),numpy=np.__version__,policy=job['policy'],n=len(records),session_init_ms=init_ms,loaded=loaded,warm=warm,after=memory(),live_vs_saved_decision_disagreements=mismatches,graph_sessions=len(sessions),model_file_mb=sum(Path(job['pair'][k]['path']).stat().st_size/1e6 for k in needed),timing_sha256=sha(out/'timing.csv'),scope='fresh-process Python CPU full gate/tokenization/inference/decision pipeline; not Flutter/device timing; one measured pass per case per process'))
 print('TIMING',job['runtime'],job['policy'],job['round'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('job');run(p.parse_args().job)
