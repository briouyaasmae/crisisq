from pathlib import Path
import csv,hashlib,json,re
import numpy as np

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,default=str).encode()).hexdigest()
def atomic(path,x):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.partial');t.write_text(json.dumps(x,indent=2,allow_nan=False));t.replace(p)
def freeze(path,x):
 p=Path(path)
 if p.exists():assert json.loads(p.read_text())==x,'Frozen file differs; preserve this run and use NEW output and temporary directories: '+str(p)
 else:atomic(p,x)
 return digest(x)
def write_csv(path,rows):
 if not rows:return
 with Path(path).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def fit_width(p,gate,cal,tau,budget,side):
 # Budget is an engineering call fraction, not a new classification threshold.
 p=np.asarray(p);route=np.asarray(gate)<0;cal=np.asarray(cal,int)
 pool=cal[route[cal]];k=int(np.floor(budget*len(pool)))
 eligible=pool[p[pool]<tau] if side=='one_sided' else pool
 distance=np.abs(p[eligible]-tau)
 if not len(distance) or k==0:return 0.
 if k>=len(distance):return float(np.nextafter(distance.max(),np.inf))
 return float(np.sort(distance)[k])  # strict <; tied boundary can underuse budget

def mask(p,g,tau,side,width):
 p=np.asarray(p);m=(np.asarray(g)<0)&(np.abs(p-tau)<width)
 if side=='one_sided':m&=p<tau
 return m

def decision(p,g,tau):return np.where(np.asarray(g)<0,np.asarray(p)>=tau,np.asarray(g)).astype(np.int8)
def routed_prediction(q,f,g,tau,which):
 q=np.asarray(q);f=np.asarray(f);return decision(np.where(which,f,q),g,tau)
def metric(y,p,ref,q):
 y=np.asarray(y);p=np.asarray(p);ref=np.asarray(ref);q=np.asarray(q);pos=y==1;neg=y==0
 def rate(num,den):return float(num/den) if den else None
 return dict(n=len(y),n_positive=int(pos.sum()),n_negative=int(neg.sum()),source_positive_recall=rate((p[pos]==1).sum(),pos.sum()),source_negative_alert_rate=rate((p[neg]==1).sum(),neg.sum()),source_label_agreement=float((p==y).mean()),positive_losses_vs_fp32=int((pos&(ref==1)&(p==0)).sum()),positive_gains_vs_fp32=int((pos&(ref==0)&(p==1)).sum()),positive_gains_vs_quantized=int((pos&(q==0)&(p==1)).sum()),positive_losses_vs_quantized=int((pos&(q==1)&(p==0)).sum()),added_source_negative_alerts_vs_quantized=int((neg&(q==0)&(p==1)).sum()),removed_source_negative_alerts_vs_quantized=int((neg&(q==1)&(p==0)).sum()),decisions_different_from_fp32=int((p!=ref).sum()))
def group_delta(y,a,b,groups,positive,repeats=1000):
 y=np.asarray(y);ix=np.flatnonzero(y==(1 if positive else 0))
 if not len(ix):return (None,None)
 groups=np.asarray(groups);unique=np.unique(groups[ix]);sums=np.array([(np.asarray(b)[ix[groups[ix]==v]]-np.asarray(a)[ix[groups[ix]==v]]).sum() for v in unique],float);counts=np.array([(groups[ix]==v).sum() for v in unique])
 rng=np.random.default_rng(20261115);samples=rng.integers(len(unique),size=(repeats,len(unique)));d=sums[samples].sum(1)/counts[samples].sum(1)
 return tuple(float(x) for x in np.quantile(d,[.025,.975]))
def gates(rules):
 scope={'re':re,'_C':[(a,b,re.compile(c)) for a,b,c in rules['crisis']],'_S':[(a,b,re.compile(c)) for a,b,c in rules['safe']],'V2_NEGATORS':set(rules['negators']),'V2_CONTRAST':re.compile(rules['contrast']),'V2_RISK_CUES':re.compile(rules['risk'])}
 exec(rules['source'],scope) # only our locally bundled hash-frozen source
 return scope['stage1_v2']
