import os
os.environ["MPLBACKEND"] = "Agg"  # Set BEFORE any Matplotlib import, including installation probes.
from pathlib import Path
import csv,json,random,shutil,statistics,subprocess,sys,zipfile
from common import sha,digest,atomic,freeze,write_csv
import environment,prepare
HERE=Path(__file__).resolve().parent

def pack(root):
 root=Path(root);target=root.with_name(root.name+'_reports.zip')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(root)))
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  assert not any(n.endswith(('.onnx','texts.json','testing-set.csv','full_evaluation_cases.jsonl','tokenizer.json')) for n in z.namelist())
 return target

def install(config,version):
 root=Path(config['output_root']);python=environment.ensure_environment(Path(config['temporary_root'])/('runtime_'+version))
 packages=['numpy==2.1.3','onnxruntime=='+version,'tokenizers==0.23.3']+(['matplotlib==3.10.7'] if version=='1.31.1' else [])
 check='import numpy,onnxruntime,tokenizers;assert numpy.__version__=="2.1.3" and onnxruntime.__version__=="'+version+'" and tokenizers.__version__=="0.23.3"'+(';import matplotlib;assert matplotlib.__version__=="3.10.7"' if version=='1.31.1' else '')
 if subprocess.run([str(python),'-I','-c',check],capture_output=True).returncode:
  log=root/('install_'+version+'.log')
  with log.open('w') as f:status=subprocess.run(environment.pip_command(python,'install','--only-binary=:all:',*packages),stdout=f,stderr=subprocess.STDOUT)
  if status.returncode:raise RuntimeError('Pinned installation failed; no silent substitution. '+log.read_text()[-3000:])
 info=json.loads(subprocess.check_output([str(python),'-I','-c','import sys,json,onnxruntime as o,numpy;print(json.dumps(dict(runtime=o.__version__,numpy=numpy.__version__,build=o.get_build_info(),module=o.__file__,python=sys.version)))'],text=True));native=Path(info['module']).parent;info['native_hashes']={str(p.relative_to(native)):sha(p) for p in sorted(native.rglob('*.so'))};freeze(root/('runtime_'+version+'.json'),info)
 return python

def main(config_path):
 config=json.loads(Path(config_path).read_text());root=Path(config['output_root']);temp=Path(config['temporary_root']);root.mkdir(parents=True,exist_ok=True)
 assert config['runtime_versions']==['1.31.1','1.28.0'] and config['model_scope'] in ['primary_only','fixed_extensions'] and config['timing_rounds']==3
 try:
  source=root/'source_code';source.mkdir(exist_ok=True)
  for path in HERE.iterdir():
   if path.is_file():shutil.copy2(path,source/path.name)
  plan=prepare.main(config);runtime={v:install(config,v) for v in config['runtime_versions']}
  jobs=json.loads((root/'score_jobs.json').read_text());jobdir=root/'job_specs';jobdir.mkdir(exist_ok=True)
  for job in jobs:
   path=jobdir/(job['id']+'.json');freeze(path,job);done=Path(job['output'])/'complete.json'
   if done.exists():
    rec=json.loads(done.read_text());assert rec['job_identity']==digest(job) and sha(Path(job['output'])/'predictions.npz')==rec['prediction_sha256'];continue
   subprocess.run([str(runtime[job['runtime']]),str(HERE/'inference_worker.py'),str(path)],check=True)
  subprocess.run([str(runtime['1.31.1']),str(HERE/'analyze.py'),str(root)],check=True)
  timing=json.loads((root/'timing_jobs_frozen.json').read_text());expanded=[]
  for round_number in range(config['timing_rounds']):
   ordered=timing.copy();random.Random(20261115+round_number).shuffle(ordered)
   for job in ordered:
    name=job['runtime']+'__'+job['policy']+'__r'+str(round_number);expanded.append({**job,'round':round_number,'output_root':str(root),'temporary_root':str(temp),'destination':str(root/'timing'/name),'id':name})
  freeze(root/'timing_schedule_frozen.json',expanded)
  for job in expanded:
   path=jobdir/(job['id']+'.json');freeze(path,job);done=Path(job['destination'])/'complete.json'
   if done.exists():
    rec=json.loads(done.read_text());assert rec['job_sha256']==sha(path) and sha(Path(job['destination'])/'timing.csv')==rec['timing_sha256'];continue
   subprocess.run([str(runtime[job['runtime']]),str(HERE/'benchmark.py'),str(path)],check=True)
  # Timing summaries retain process rounds rather than treating repeated cases as new messages.
  aggregate=[]
  for job in expanded:
   record=json.loads((Path(job['destination'])/'complete.json').read_text());rows=list(csv.DictReader((Path(job['destination'])/'timing.csv').open()))
   for part in sorted({r['partition'] for r in rows}):
    selected=[r for r in rows if r['partition']==part];aggregate.append(dict(runtime=job['runtime'],policy=job['policy'],round=job['round'],partition=part,n=len(selected),mean_ms=sum(float(r['elapsed_ms']) for r in selected)/len(selected),fp32_calls=sum(int(r['fp32_calls']) for r in selected),compressed_calls=sum(int(r['compressed_calls']) for r in selected),post_warm_pss_mib=record['warm']['pss_mib'],peak_rss_mib=record['after']['peak_rss_mib'],model_file_mb=record['model_file_mb'],session_init_ms=record['session_init_ms'],live_vs_saved_disagreements=record['live_vs_saved_decision_disagreements']))
  write_csv(root/'timing_run_means.csv',aggregate)
  summarized=[]
  for version,policy,part in sorted({(r['runtime'],r['policy'],r['partition']) for r in aggregate}):
   rr=[r for r in aggregate if (r['runtime'],r['policy'],r['partition'])==(version,policy,part)];base=[r['mean_ms'] for r in aggregate if r['runtime']==version and r['partition']==part and r['policy']=='always_fp32'];mean=statistics.mean(r['mean_ms'] for r in rr)
   pss=[r['post_warm_pss_mib'] for r in rr if r['post_warm_pss_mib'] is not None]
   summarized.append(dict(runtime=version,policy=policy,partition=part,process_rounds=len(rr),unique_timing_messages=rr[0]['n'],mean_of_run_means_ms=mean,sd_of_run_means_ms=statistics.stdev(r['mean_ms'] for r in rr) if len(rr)>1 else 0.,speedup_vs_fp32=statistics.mean(base)/mean,mean_post_warm_pss_mib=statistics.mean(pss) if pss else None,model_file_mb=rr[0]['model_file_mb'],scope='host full Python pipeline; repeated process rounds; not phone performance'))
  write_csv(root/'timing_summary.csv',summarized)
  metrics=list(csv.DictReader((root/'metrics.csv').open()));references=list(csv.DictReader((root/'matched_random_reference.csv').open()));findings=['Primary fixed policy: one_sided_05. These are inspected-source follow-up results, not independent validation.']
  for version in config['runtime_versions']:
   for part in ['binary_test','sdcnl_authors_test']:
    r=next(x for x in metrics if x['model']=='saqs__42' and x['runtime']==version and x['partition']==part and x['policy']=='one_sided_05');q=next(x for x in metrics if x['model']=='saqs__42' and x['runtime']==version and x['partition']==part and x['policy']=='always_compressed');ref=next(x for x in references if x['model']=='saqs__42' and x['runtime']==version and x['partition']==part);t=next(x for x in summarized if x['runtime']==version and x['partition']==part and x['policy']=='one_sided_05')
    findings.append(f"{version} {part}: source-positive losses vs FP32 {q['positive_losses_vs_fp32']} -> {r['positive_losses_vs_fp32']}; recovered={r['positive_gains_vs_quantized']}; random expected recovery={float(ref['random_expected_recovered']):.3f}; added source-negative alerts={r['added_source_negative_alerts_vs_quantized']}; actual fallback fraction={r['fallback_fraction_all_messages']}; host speedup vs FP32={t['speedup_vs_fp32']:.3f}; post-warm PSS MiB={t['mean_post_warm_pss_mib']}.")
  (root/'KEY_FINDINGS.txt').write_text('\n'.join(findings)+'\nDo not choose another budget from sensitivity outcomes. FP32 reference is not clinical ground truth. Co-resident models sacrifice quantized-only storage/memory benefits.\n')
  for name in ['HOW_TO_RUN.txt','PROTOCOL.txt']:
   if (HERE/name).exists():shutil.copy2(HERE/name,root/name)
  mismatch=sum(json.loads((Path(j['destination'])/'complete.json').read_text())['live_vs_saved_decision_disagreements'] for j in expanded)
  atomic(root/'completion.json',dict(complete=True,score_jobs=len(jobs),timing_jobs=len(expanded),timing_live_vs_saved_disagreements=mismatch,all_implementations_match_expected=mismatch==0,model_pairs=len(plan['models']),classification_thresholds_unchanged=True,clinical_or_unseen_data_validation=False))
  status=json.loads((root/'analysis_complete.json').read_text());status['benchmark_complete']=True;atomic(root/'analysis_complete.json',status)
  failure=root/'failure.json'
  if failure.exists():
   history=root/'resolved_failures';history.mkdir(exist_ok=True);failure.replace(history/(sha(failure)+'.json'))
  files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts]
  (root/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(root))+'\n' for p in files))
  print('COMPLETE. Return:',pack(root),flush=True)
 except Exception as error:
  atomic(root/'failure.json',dict(complete=False,error_type=type(error).__name__,message=str(error)));print('INCOMPLETE report:',pack(root),flush=True);raise
if __name__=='__main__':main(sys.argv[1])
